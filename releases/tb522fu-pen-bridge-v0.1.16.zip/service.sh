#!/system/bin/sh

MODDIR=${0%/*}

# ============================================================================
# 联想手写笔桥接 Root 服务 · service（开机完成后）阶段
# 实际修复与作用：
#   1) 开机按已绑定手写笔地址直接调用原厂 CoreService 的 CONNECT_PENCIL
#      BLE 连接（不以 Hall/CPS 为前提），并做有限次重试；
#   2) 设置页断开时调用 DISCONNECT_PENCIL，由配套 LSPosed Hook 执行
#      BluetoothGatt.disconnect()，使设备/HID 真实离开连接态；
#   3) 常驻监控真实 ACL/GATT/Hall/CPS 事件，驱动 ColorOS 设置页手写笔
#      卡片、磁吸胶囊、电量与存在状态（状态只跟随真实事件，不强行回放）；
#   4) CPS 开机上电：仅在真实磁吸 Hall 对为 0:1 时保持 CPS GPIO，磁吸只
#      负责充电与弹窗；不使用自定义内核模块；
#   5) PenHidCtl（priv-app HID 控制器）开机授予蓝牙运行时权限，只调后台
#      PenHidService，无启动器入口；
#   6) 不监听屏幕状态、不做唤醒回放：状态只跟随真实 Hall/GATT/Root 事件。
#      早期版本在唤醒后延迟回放过一次，那是为了绕开"唤醒瞬间写 DSI/panel 节点
#      导致黑屏"；后来改成 pen_wakeup_* 只在开机按需写一次，回放就没必要了，
#      代码也早已删除（本文件里搜不到任何屏幕状态监听）。
#   7) 刷新率策略由 post-fs-data 绑定，本服务不管理亮度/背光/屏幕电源。
# 仅适用于 SM8650Q / pineapple 平台；Hook 仍独立安装，模块内签名副本
# 仅用于 LSPosed 在 PackageManager 恢复 /data/app 前稳定读取。
# ============================================================================

LOGFILE="$MODDIR/pen-bridge.log"
MODE=/proc/pen_wakeup_mode
SWITCH=/proc/pen_wakeup_switch
UEVENT=/sys/devices/virtual/lenovo_penraw/lenovo_penraw/uevent
# TB522FU (sun/SM8750P): och1909 hall driver exposes four channels.
# Calibrated 2026-09-18: pen magnetic dock == hall3, attached reads 0,
# detached reads 1. hall1_1/hall1_2 idle 0, hall2 idle 1 (kbd cover side).
PEN1_HALL=/sys/devices/virtual/hall/och1909/hall3
CPS_GPIOCHIP=gpiochip0
CPS_GPIODEV=/dev/gpiochip0
CPS_GPIOSET=/system/bin/gpioset
CPS_HELPER="$MODDIR/bin/pen-cps-gpio"
CPS_PEN_HALL=/sys/devices/virtual/hall/och1909/hall3
# CPS8601 无线充节点。此前写死的是 pineapple/SM8650Q 的地址
# （…/qupv3_i2c_geni_se/98c000.i2c/i2c-2/2-0041），在 sun/SM8750P 上该路径
# 根本不存在，于是所有 CPS 读取静默空转、模块自己永远产不出新鲜样本
# （2026-09-18 实测：本机挂在 11-0041）。CPS8601 的 I2C 地址恒为 0x41，
# 用总线符号链接按地址解析即可同时兼容两块板子；这也是 charge-guard.sh
# 已经验证过的稳定路径形式。
CPS_UEVENT=
CPS_TX_STATUS=
CPS_PS_ONLINE=
resolve_cps_nodes() {
    for dir in /sys/bus/i2c/devices/*-0041; do
        [ -d "$dir" ] || continue
        [ -r "$dir/tx_status" ] || continue
        CPS_TX_STATUS="$dir/tx_status"
        [ -r "$dir/uevent" ] && CPS_UEVENT="$dir/uevent"
        break
    done
    [ -r /sys/class/power_supply/cps_wls_tx/online ] && \
        CPS_PS_ONLINE=/sys/class/power_supply/cps_wls_tx/online
}
resolve_cps_nodes
CPS_PIDFILE="$MODDIR/cps-gpio.pid"
CPS_DISABLED="$MODDIR/disable"
HALL_STATE_FILE="$MODDIR/pen-hall.state"
CAPSULE_DEDUP_FILE="$MODDIR/pen-capsule.last"
CAPSULE_WORKER_FILE="$MODDIR/pen-capsule.worker"
CAPSULE_DEDUP_SECONDS=4
SERVICE_LOCK="$MODDIR/.service.lock"
HIDCTL_SERVICE=com.aclaniakea.penhidctl/.PenHidService
OEM_CORE_SERVICE=com.oplus.ipemanager/.btadsorb.CoreService
OEM_CONNECT_ACTION=com.oplus.ipemanager.action.CONNECT_PENCIL
OEM_DISCONNECT_ACTION=com.oplus.ipemanager.action.DISCONNECT_PENCIL
PEN_CONNECT_DEDUP_FILE="$MODDIR/pen-connect.last"
PEN_BOOT_READY_FILE="$MODDIR/pen-boot-ready"
HIDCTL_PERMISSION_FILE="$MODDIR/pen-hid-permissions.ready"
BRIDGE_PERMISSION_FILE="$MODDIR/pen-bridge-permissions.ready"
HIDCTL_LAUNCHER_FILE="$MODDIR/pen-hid-launcher.hidden"
PEN_USER_DISCONNECT_KEY=lenovo_pen_user_disconnect_requested
BRIDGE_PKG=com.futureharmony.lenovopenbridge
BRIDGE_PKG_LEGACY=com.aclaniakea.lenovopenbridge

# Respawn guard: if the real service exits (crash, OOM, kill), bring it
# back after a short delay. KernelSU can invoke service.sh several times
# during boot (module refresh, boot-completed callbacks), so only one
# invocation may own the respawn loop and the monitors.
#
# The singleton lock is an exclusive flock on $SERVICE_LOCK held by the
# first invocation's file descriptor. The descriptor is inherited by the
# background respawn loop and by each service child, so exactly one loop
# (and one monitor set) stays alive for the whole session. Later KernelSU
# invocations fail the non-blocking lock and exit immediately. If the loop
# dies, the descriptor closes, the lock is released, and a later invocation
# takes over.
if [ -z "$PEN_SERVICE_RESPAWN" ]; then
    if [ -d "$SERVICE_LOCK" ]; then
        # Legacy mkdir lock from older builds; replace it with the flock file.
        rm -rf "$SERVICE_LOCK" 2>/dev/null
    fi
    exec 9>"$SERVICE_LOCK" 2>/dev/null || exit 0
    if ! /data/adb/ksu/bin/busybox flock -n 9 2>/dev/null; then
        # Either the lock is taken or busybox flock is unavailable; in both
        # cases exit without running a second monitor set.
        exit 0
    fi
    export PEN_SERVICE_RESPAWN=1
    (
        while [ ! -e "$CPS_DISABLED" ]; do
            sh "$0"
            sleep 8
        done
    ) &
    exit 0
fi

soc=$(getprop ro.soc.model)
platform=$(getprop ro.board.platform)
case "$soc/$platform" in
    *SM8750P*/*sun*) ;;
    *) echo "unsupported device: soc=$soc platform=$platform" >"$LOGFILE"; exit 0;;
esac

# --- 启动失败自保：清除 post-fs-data 的失败计数 -----------------------------
# post-fs-data.sh 每次开机先 +1 记账，连续失败超阈值就熔断（见该文件）。
# 只有系统【真正】到达 sys.boot_completed=1 才清零——否则一个能跑到
# late_start 但随后崩掉的坏镜像会被误判为“启动成功”，计数被白白清空。
# 后台等待，不阻塞本服务启动。
(
    _n=0
    while [ "$_n" -lt 180 ]; do
        [ "$(getprop sys.boot_completed 2>/dev/null)" = "1" ] && break
        sleep 2
        _n=$((_n + 1))
    done
    if [ "$(getprop sys.boot_completed 2>/dev/null)" = "1" ]; then
        rm -f /data/adb/tb522fu_pen_bridge.bootfail 2>/dev/null
    fi
) &

# --- inkdye（系统内置笔桥）默认禁用，由本模块接管；可在管理器里手动开启 ---
# 默认行为：开机把内置笔桥 `com.inkdye.lenovopentocoloros` 降级（disable-user），
# 使笔能力交由本模块（Root 服务 + Hook）接管。
# 如需回退到系统内置笔桥：在 KernelSU/Magisk 管理器「执行」按钮运行
# `action.sh enable`（写入 inkdye-enabled.state 并持续维持）。
# 切换入口：KSU 管理器「执行」或 `sh $MODDIR/action.sh enable|disable|toggle`。
INKDYE_PKG=com.inkdye.lenovopentocoloros
INKDYE_STATE="$MODDIR/inkdye-enabled.state"
# 迁移：旧语义的 inkdye-disabled.state（"用户曾选择禁用"）在新默认下已等价于默认值，清掉。
rm -f "$MODDIR/inkdye-disabled.state" 2>/dev/null
# ⚠️ 实际的 pm enable/disable 不在这里执行：service.sh 跑到这一段时
#    PackageManager 往往还没就绪，`pm disable-user` 会【静默失败】。
#    实测（2026-09-18）：这里打印了 "inkdye disabled by default"，但 dumpsys
#    仍是 enabled=0，`pm list packages -d` 也没有它 —— 即"日志说禁了，实际没禁"。
#    真正的落地点在下面 exec 重定向之后的 apply_inkdye_state（带重试 + 状态复核）。

# 本服务把整个输出重定向进日志，模块目录在 /data/adb 下又没有任何外部轮转，
# 此前是无限追加。开机先滚一次，保留上一轮现场；运行中由下面的
# trim_log_if_large 兜底 —— 实际裁剪逻辑统一在 bin/penlog.sh（条数 + 字节双上限）。
# ⚠️ exec >> 用的是 O_APPEND，所以裁剪必须【同 inode 就地回写】，绝不能 mv
#    （详见 bin/penlog.sh 顶部说明：mv 会把日志写进已 unlink 的旧 inode）。
LOG_MAX_BYTES=524288
LOG_MAX_LINES=400
if [ -f "$MODDIR/bin/penlog.sh" ]; then
    . "$MODDIR/bin/penlog.sh"
fi
# 降级兜底：老版本安装（zip 里还没有 bin/penlog.sh）时至少不要把日志写爆，
# 退回"超字节上限才整file清空"的旧行为。
if ! type penlog_trim >/dev/null 2>&1; then
    penlog_trim() {
        _sz=$(wc -c <"$1" 2>/dev/null)
        case "$_sz" in ''|*[!0-9]*) return 0 ;; esac
        [ "$_sz" -lt "${3:-524288}" ] && return 0
        : >"$1" 2>/dev/null
    }
fi
if [ -f "$LOGFILE" ]; then
    # 上一轮日志先裁一遍再留档：长开机（>1 天）时 .1 也不会变成巨型文件。
    penlog_trim "$LOGFILE" "$LOG_MAX_LINES" "$LOG_MAX_BYTES"
    mv -f "$LOGFILE" "$LOGFILE.1" 2>/dev/null
fi
# 上一次服务实例可能被 kill 在胶囊重试循环中间，留下 worker 标记文件；
# 不清掉会让本次开机所有磁吸边沿都不再尝试广播胶囊。
rm -f "$CAPSULE_WORKER_FILE" 2>/dev/null

trim_log_if_large() {
    # 条数（400 行）+ 字节（512 KB）双上限，超限保留最近行而不是整file清空：
    # 控制台只显示尾部片段，清空等于把现场丢干净，下次报障无据可查。
    penlog_trim "$LOGFILE" "$LOG_MAX_LINES" "$LOG_MAX_BYTES"
}

exec >>"$LOGFILE" 2>&1
echo "[$(date '+%F %T')] service start"

# --- inkdye 落地：等 PackageManager 就绪后重试，直到状态复核通过 --------------
# 早期 service.sh 阶段 pm enable/disable 会静默失败，因此这里后台重试（不阻塞
# 主流程），并用 `pm list packages -d` 复核实际状态，避免"日志说禁了其实没禁"。
inkdye_is_disabled() {
    pm list packages -d --user 0 2>/dev/null | grep -q "^package:${INKDYE_PKG}$"
}
apply_inkdye_state() {
    i=0
    if [ -f "$INKDYE_STATE" ]; then
        # 用户显式选择启用 → 维持系统内置笔桥
        while [ "$i" -lt 40 ]; do
            pm enable --user 0 "$INKDYE_PKG" >/dev/null 2>&1
            if ! inkdye_is_disabled; then
                echo "[$(date '+%F %T')] inkdye kept ENABLED (user choice via action.sh)"
                return 0
            fi
            i=$((i + 1)); sleep 3
        done
        echo "[$(date '+%F %T')] WARN inkdye enable not confirmed after $i tries"
    else
        # 默认：禁用系统内置笔桥
        while [ "$i" -lt 40 ]; do
            pm disable-user --user 0 "$INKDYE_PKG" >/dev/null 2>&1
            if inkdye_is_disabled; then
                echo "[$(date '+%F %T')] inkdye disabled by default (enable via action.sh)"
                return 0
            fi
            i=$((i + 1)); sleep 3
        done
        echo "[$(date '+%F %T')] WARN inkdye disable not confirmed after $i tries"
    fi
}
apply_inkdye_state &

# --- 防整机重启：禁用/停止移植ROM缺失专有驱动的高危服务 ---
apply_system_stability_fixes() {
    stop vendor.urcc-hal-aidl 2>/dev/null
    setprop ctl.stop vendor.urcc-hal-aidl 2>/dev/null
    i=0
    while [ "$i" -lt 40 ]; do
        pm disable com.oplus.gesture >/dev/null 2>&1
        if pm list packages -d 2>/dev/null | grep -q "^package:com.oplus.gesture$"; then
            echo "[$(date '+%F %T')] com.oplus.gesture disabled for boot stability"
            break
        fi
        i=$((i + 1)); sleep 3
    done
}
apply_system_stability_fixes &

# 不 fork 的等待。
#
# 每次调用外部 sleep 都是一次 fork+exec，而本服务有 6 处 1 秒轮询、3 处 2 秒
# 轮询，外加若干子 shell。实测代价：笔桥接运行时全系统 26 forks/s，停掉它只剩
# 8 forks/s——**它一个模块占了全系统进程创建的 69%**，而且笔没在使用时照跑不误
# （10 个常驻 shell、合计 RSS 7.7 MB、持续约 1% CPU）。
#
# read 是 shell 内建命令。把一个只读不写的 fifo 以读写方式常开在 fd 8 上，
# `read -t N -u 8` 就会阻塞到超时再返回，全程不创建进程。fifo 必须用 <> 打开，
# 否则没有写端时 read 会立刻拿到 EOF 而不是等待。
#
# fd 用 8：9 已被上面的 SERVICE_LOCK 占用。
# 自检失败（shell 不支持 read -t、fifo 建不出来、或立刻返回而不是等待）时
# 原样回退到外部 sleep，行为与改动前完全一致。
NAP_FIFO="$MODDIR/.nap.fifo"
NAP_READY=0

nap_init() {
    [ -p "$NAP_FIFO" ] || {
        rm -f "$NAP_FIFO" 2>/dev/null
        mknod "$NAP_FIFO" p 2>/dev/null || mkfifo "$NAP_FIFO" 2>/dev/null
    }
    [ -p "$NAP_FIFO" ] || return 1
    exec 8<>"$NAP_FIFO" 2>/dev/null || return 1
    # 自检：请求等 0.3 秒，必须真的耗掉 >=200ms。若 shell 不支持 -t 或直接
    # 拿到 EOF 就会立刻返回，那种情况下用它会把轮询变成忙等，必须回退。
    _nap_t0=$(date +%s%N 2>/dev/null) || return 1
    read -t 0.3 -u 8 _nap_discard 2>/dev/null
    _nap_t1=$(date +%s%N 2>/dev/null) || return 1
    [ $(( (_nap_t1 - _nap_t0) / 1000000 )) -ge 200 ] || return 1
    NAP_READY=1
    return 0
}

sleep_sec() {
    if [ "$NAP_READY" = 1 ]; then
        read -t "$1" -u 8 _nap_discard 2>/dev/null
        return 0
    fi
    # Use the root runtime's BusyBox first.  On this ROM /system/bin/toybox can
    # appear executable while its mount namespace is still settling; invoking it
    # then fails and a polling loop can spin at 100% CPU.
    for sleep_backend in \
            /data/adb/ksu/bin/busybox \
            /data/adb/magisk/busybox \
            /system/bin/toybox; do
        [ -x "$sleep_backend" ] || continue
        if "$sleep_backend" sleep "$1" >/dev/null 2>&1; then
            return 0
        fi
    done
    echo "[$(date '+%F %T')] no working sleep backend; stopping service to avoid a busy loop"
    exit 0
}

if nap_init; then
    echo "[$(date '+%F %T')] nap: 使用内建 read -t（不 fork）"
else
    echo "[$(date '+%F %T')] nap: 自检未通过，回退外部 sleep"
fi

count=0
while { [ ! -e "$MODE" ] || [ ! -e "$SWITCH" ]; } && [ "$count" -lt 60 ]; do
    sleep_sec 1
    count=$((count + 1))
done

apply_pen_wake() {
    mode=$(cat "$MODE" 2>/dev/null | tr -d '\r')
    wake=$(cat "$SWITCH" 2>/dev/null | tr -d '\r')
    mode_write=0
    switch_write=0

    # system_server cannot write these vendor proc nodes on this ROM.  The
    # Root service is the only writer, and writes each node only when it is
    # not already enabled.  This avoids the old repeated DSI/panel writes
    # while still enabling the CPS pen-wakeup path once after boot.
    if [ "$mode" != 1 ] && [ -w "$MODE" ]; then
        if printf '1\n' >"$MODE" 2>/dev/null; then
            mode_write=1
        fi
    fi
    if [ "$wake" != 1 ] && [ -w "$SWITCH" ]; then
        if printf '1\n' >"$SWITCH" 2>/dev/null; then
            switch_write=1
        fi
    fi

    mode=$(cat "$MODE" 2>/dev/null | tr -d '\r')
    wake=$(cat "$SWITCH" 2>/dev/null | tr -d '\r')
    echo "[$(date '+%F %T')] pen wake root apply mode=$mode switch=$wake wrote_mode=$mode_write wrote_switch=$switch_write"
}

# The CPS driver or vendor power manager can reset these proc switches after
# boot. Keep the kernel wake path enabled while the module is active, but only
# rewrite a node after observing that it has been turned off.
monitor_pen_wake() {
    while [ ! -e "$CPS_DISABLED" ]; do
        mode=$(cat "$MODE" 2>/dev/null | tr -d '\r')
        wake=$(cat "$SWITCH" 2>/dev/null | tr -d '\r')
        # Both proc nodes read back as a bare "1" on this kernel. The old
        # monitor also demanded $SWITCH equal the literal string
        # "Pen Wakeup SWITCH 1!", which never matched, so the guard fired on
        # EVERY 30 s pass: it logged "pen wake node reset detected" while
        # apply_pen_wake then declined to write anything (wrote_*=0). That
        # constant false alarm buried the real disconnect signal in the log.
        # Accept either encoding; only a genuinely disabled node is a reset.
        if [ -n "$mode" ] && [ -n "$wake" ] \
                && { [ "$mode" != 1 ] \
                     || { [ "$wake" != 1 ] && [ "$wake" != "Pen Wakeup SWITCH 1!" ]; }; }; then
            echo "[$(date '+%F %T')] pen wake node reset detected mode=$mode switch=$wake"
            apply_pen_wake
        fi
        sleep_sec 30
    done
}

# v1.0.61 wrote a connected snapshot immediately after requesting GATT.  That
# snapshot could survive a module update and make the next boot look connected
# even when Bluetooth had no live link.  Start this revision from a neutral
# mirror; the OEM ACL/GATT and real Hall/CPS events repopulate it afterward.
# Keep the explicit user disconnect choice and the last valid battery sample
# intact. The operational latch is normalized separately at boot: an ACL
# disconnect emitted during a normal reboot must not block the next boot.
# Bluetooth recovery below is intentionally independent of the physical Hall
# pair; Hall is only used by the CPS and magnetic-capsule paths.
reset_pen_state_mirror() {
    for key in \
            lenovo_pen_link_connected \
            ipe_pencil_connect_state \
            ipe_pencil_connection_state \
            PENCIL_CONNECT_STATE \
            pencil_connect_state; do
        settings put global "$key" 0 >/dev/null 2>&1
    done
    settings put global lenovo_pen_refresh_active 0 >/dev/null 2>&1
    settings put global settings_enable_oppo_pencil 0 >/dev/null 2>&1
    settings put global ipe_pencil_present 0 >/dev/null 2>&1
    settings put global ipe_pencil_charging_state 0 >/dev/null 2>&1
    settings put global lenovo_pen_physical_docked 0 >/dev/null 2>&1
    settings put global lenovo_pen_hardware_battery_valid 0 >/dev/null 2>&1
    settings put global lenovo_pen_oem_charge_valid 0 >/dev/null 2>&1
    echo "[$(date '+%F %T')] stale v1.0.61 connection mirror cleared"
}

normalize_disconnect_latch() {
    user_requested=$(settings get global "$PEN_USER_DISCONNECT_KEY" 2>/dev/null | tr -d '\r')
    case "$user_requested" in
        1|0) ;;
        *) user_requested=0 ;;
    esac
    # lenovo_pen_disconnect_requested is a runtime guard. Do not carry a
    # natural ACL shutdown from the previous boot into the next boot; only an
    # explicit settings-page Disconnect is persistent across reboot.
    settings put global "$PEN_USER_DISCONNECT_KEY" "$user_requested" >/dev/null 2>&1
    settings put global lenovo_pen_disconnect_requested "$user_requested" >/dev/null 2>&1
    echo "[$(date '+%F %T')] disconnect latch normalized user=$user_requested"
}

until [ "$(getprop sys.boot_completed)" = 1 ]; do
    sleep_sec 2
done
normalize_disconnect_latch
# OEM GATT readiness belongs to the current IPeManager process/session.  A
# persisted value from the previous boot makes system_server broadcast haptic
# commands to a dynamic receiver that no longer exists, suppressing the direct
# GATT fallback.  The Hook writes the live owner PID after service discovery.
settings put global lenovo_pen_oem_control_ready 0 >/dev/null 2>&1
settings put global lenovo_pen_oem_control_pid 0 >/dev/null 2>&1
settings put global lenovo_pen_oem_haptic_forward 1 >/dev/null 2>&1
echo "[$(date '+%F %T')] stale OEM haptic transport session cleared"
apply_pen_wake
reset_pen_state_mirror
monitor_pen_wake &

# Priv-app allowlists do not grant Android 12+ Bluetooth runtime permissions.
# Root only calls PenHidCtl's explicit service component. The APK has no
# launcher intent, so authorize that service before issuing any HID command.
grant_hidctl_bluetooth_permissions() {
    [ -f "$HIDCTL_PERMISSION_FILE" ] && return 0
    if [ -z "$(pm path com.aclaniakea.penhidctl 2>/dev/null)" ]; then
        echo "[$(date '+%F %T')] HID permission grant skipped: helper APK unavailable"
        return 0
    fi
    failed=0
    for permission in \
            android.permission.BLUETOOTH_CONNECT \
            android.permission.BLUETOOTH_SCAN; do
        if ! pm grant --user 0 com.aclaniakea.penhidctl "$permission" >/dev/null 2>&1; then
            failed=1
            echo "[$(date '+%F %T')] HID permission grant failed permission=$permission"
        fi
    done
    if [ "$failed" = 0 ]; then
        : >"$HIDCTL_PERMISSION_FILE"
        echo "[$(date '+%F %T')] HID Bluetooth runtime permissions granted"
    fi
}

# The haptic transport deliberately lives in the standalone bridge process so
# a vendor Bluetooth failure cannot restart system_server. Package updates can
# revoke nearby-device runtime grants, so make the isolation path self-healing.
grant_bridge_bluetooth_permissions() {
    [ -f "$BRIDGE_PERMISSION_FILE" ] && return 0
    target_pkg=""
    if [ -n "$(pm path "$BRIDGE_PKG" 2>/dev/null)" ]; then
        target_pkg="$BRIDGE_PKG"
    elif [ -n "$(pm path "$BRIDGE_PKG_LEGACY" 2>/dev/null)" ]; then
        target_pkg="$BRIDGE_PKG_LEGACY"
    elif [ -f "$MODDIR/hook/PenBridge-Hook.apk" ]; then
        pm install -r "$MODDIR/hook/PenBridge-Hook.apk" >/dev/null 2>&1
        if [ -n "$(pm path "$BRIDGE_PKG" 2>/dev/null)" ]; then
            target_pkg="$BRIDGE_PKG"
        fi
    fi
    if [ -z "$target_pkg" ]; then
        echo "[$(date '+%F %T')] bridge permission grant skipped: Hook APK unavailable"
        return 0
    fi
    failed=0
    for permission in \
            android.permission.BLUETOOTH_CONNECT \
            android.permission.BLUETOOTH_SCAN; do
        if ! pm grant --user 0 "$target_pkg" "$permission" >/dev/null 2>&1; then
            failed=1
            echo "[$(date '+%F %T')] bridge permission grant failed permission=$permission pkg=$target_pkg"
        fi
    done
    if [ "$failed" = 0 ]; then
        : >"$BRIDGE_PERMISSION_FILE"
        echo "[$(date '+%F %T')] bridge Bluetooth runtime permissions granted for $target_pkg"
    fi
}

# The bridge Hook APK has no launcher component, so a package (re)install or
# force-stop leaves it in the stopped state. A stopped app's ContentProvider is
# not resolvable from system_server, which silently drops every haptic dispatch
# with "Failed to find provider info". Keep it un-stopped so the provider (and
# therefore the writing haptic) is always reachable.
unstop_bridge() {
    for pkg in "$BRIDGE_PKG" "$BRIDGE_PKG_LEGACY"; do
        if [ -n "$(pm path "$pkg" 2>/dev/null)" ]; then
            if pm unstop --user 0 "$pkg" >/dev/null 2>&1; then
                echo "[$(date '+%F %T')] bridge Hook APK un-stopped ($pkg)"
            fi
        fi
    done
}

hide_hidctl_launcher() {
    [ -f "$HIDCTL_LAUNCHER_FILE" ] && return 0
    if [ -z "$(pm path com.aclaniakea.penhidctl 2>/dev/null)" ]; then
        echo "[$(date '+%F %T')] HID launcher hide skipped: helper APK unavailable"
        return 0
    fi
    if pm disable --user 0 com.aclaniakea.penhidctl/.MainActivity >/dev/null 2>&1; then
        : >"$HIDCTL_LAUNCHER_FILE"
        echo "[$(date '+%F %T')] HID launcher activity disabled"
    else
        echo "[$(date '+%F %T')] HID launcher activity disable deferred"
    fi
}

retry_hidctl_setup() {
    attempt=1
    while [ "$attempt" -le 12 ] && [ ! -e "$CPS_DISABLED" ]; do
        hide_hidctl_launcher
        grant_hidctl_bluetooth_permissions
        grant_bridge_bluetooth_permissions
        unstop_bridge
        [ -f "$HIDCTL_PERMISSION_FILE" ] && [ -f "$BRIDGE_PERMISSION_FILE" ] && return 0
        sleep_sec 5
        attempt=$((attempt + 1))
    done
    echo "[$(date '+%F %T')] HID setup retry window expired"
}

hide_hidctl_launcher
grant_hidctl_bluetooth_permissions
grant_bridge_bluetooth_permissions
unstop_bridge
retry_hidctl_setup &

# The LSPosed Hook is a separate package now. This Root service deliberately
# does not call pm install and never copies an APK into /data/app.
echo "[$(date '+%F %T')] stable LSPosed Pen Hook payload expected"

# The ported OplusBatteryManager reports wirelessPenPresent=0 even when the
# real Hall pair is 0/1 (pen docked).  That makes the bridge's Java poller
# classify every magnetic edge as undocked and the OEM Capsule is never
# requested.  Read the two real Hall nodes in root context and feed the
# already-installed ColorOS handoff/capsule receiver.  Battery and charging
# still come from the CPS/GATT-backed settings and uevent; this monitor only
# repairs the physical magnetic edge.
read_hall_state() {
    # TB522FU: och1909 hall3. Driver writes prefix "hall13" (its own
    # format-string bug), so file content is "hall13 value = N" (N=0 docked).
    # The trailing-digit extraction is prefix-agnostic: fine either way.
    # The trailing-digit extraction avoids spawning tr/awk per sample.
    hall=
    [ -r "$PEN1_HALL" ] && IFS= read -r hall <"$PEN1_HALL"
    hall=${hall##* }
    case "$hall" in
        0) echo 1 ;; # docked (hall3 low when pen attached)
        1) echo 0 ;; # detached
        *) echo -1 ;;
    esac
}

valid_level() {
    case "$1" in
        ''|*[!0-9]*) return 1 ;;
    esac
    [ "$1" -ge 0 ] && [ "$1" -le 100 ]
}

read_level_from_file() {
    file="$1"
    [ -r "$file" ] || return 0
    for key in LEVEL BATTERY_LEVEL BATTERY_LEVEL_PERCENT BATTERY CAPACITY PEN_BATTERY; do
        level=$(sed -n "s/^${key}=//p" "$file" 2>/dev/null | head -1 | tr -d '\r')
        if valid_level "$level"; then
            echo "$level"
            return 0
        fi
    done
}

cache_hardware_battery() {
    level="$1"
    valid_level "$level" || return 0
    # A CPS/HID read can be repeated by several monitors.  Settings writes
    # wake SettingsProvider and IPeManager, so only publish an actual change.
    current=$(settings get global ipe_pencil_battery_level 2>/dev/null | tr -d '\r')
    [ "$current" = "$level" ] || \
        settings put global ipe_pencil_battery_level "$level" >/dev/null 2>&1
    current=$(settings get global lenovo_pen_last_valid_battery 2>/dev/null | tr -d '\r')
    [ "$current" = "$level" ] || \
        settings put global lenovo_pen_last_valid_battery "$level" >/dev/null 2>&1
    current=$(settings get global lenovo_pen_hardware_battery_valid 2>/dev/null | tr -d '\r')
    [ "$current" = 1 ] || \
        settings put global lenovo_pen_hardware_battery_valid 1 >/dev/null 2>&1
    now=$(date '+%s' 2>/dev/null)
    case "$now" in
        ''|*[!0-9]*) ;;
        *) settings put global lenovo_pen_hardware_battery_last_at "$now" >/dev/null 2>&1 ;;
    esac
}

suspect_unconnected_zero_battery() {
    [ "$1" = 0 ] || return 1
    connected=$(settings get global lenovo_pen_link_connected 2>/dev/null | tr -d '\r')
    [ "$connected" != 1 ]
}

read_hardware_battery() {
    level=$(settings get global ipe_pencil_battery_level 2>/dev/null | tr -d '\r')
    battery_valid=$(settings get global lenovo_pen_hardware_battery_valid 2>/dev/null | tr -d '\r')
    if valid_level "$level" && [ "$battery_valid" = 1 ] \
            && ! suspect_unconnected_zero_battery "$level"; then
        echo "$level"
        return 0
    fi
    level=$(read_level_from_file "$CPS_UEVENT")
    # CPS exposes LEVEL=0 while the docked pen is only waiting to power up.
    # A genuine 0% sample is still accepted from the live BLE/GATT cache, but
    # a raw kernel/CPS zero is never promoted to trusted battery state.
    connected=$(settings get global lenovo_pen_link_connected 2>/dev/null | tr -d '\r')
    if [ "$connected" = 1 ] && valid_level "$level" && [ "$level" -gt 0 ]; then
        cache_hardware_battery "$level"
        echo "$level"
        return 0
    fi
    level=$(read_level_from_file "$UEVENT")
    if [ "$connected" = 1 ] && valid_level "$level" && [ "$level" -gt 0 ]; then
        cache_hardware_battery "$level"
        echo "$level"
        return 0
    fi
    # Never turn an unavailable sample into a new 0% value.  Keep the last
    # hardware sample until the GATT link reports a fresh one.
    level=$(settings get global lenovo_pen_last_valid_battery 2>/dev/null | tr -d '\r')
    if valid_level "$level"; then
        echo "$level"
    else
        echo -1
    fi
}

read_charge_from_file() {
    file="$1"
    [ -r "$file" ] || return 0
    for key in CHARGING_STATE CHARGING CHARGE_STATE WIRELESS_CHARGING; do
        charge_state=$(sed -n "s/^${key}=//p" "$file" 2>/dev/null | head -1 | tr -d '\r')
        case "$charge_state" in
            1|Charging|charging|Charge|charge|WIRELESS_CHARGING|Wireless\ Charging)
                echo 1
                return 0
                ;;
            0|Full|full|Not\ charging|not_charging|Discharging|discharging|Idle|idle|None|none)
                echo 0
                return 0
                ;;
        esac
    done
}

read_cps_charging() {
    # CPS8601 收发器真值。本机 DT uevent 里没有 CHARGING/ATTACHED 键，
    # 所以收发器节点是唯一可信的内核侧来源：
    #   tx_status "cps_wls_en:1" -> 线圈在送电（正在充电）
    #   tx_status "cps_wls_en:0" -> 驱动已断（充满或未吸附）
    # 语义已由 charge-guard.sh 在 2026-09-18 实测确认：笔充满时驱动会自己
    # 置 cps_wls_en:0。因此它同时是「充电中」与「笔在不在线圈上」的真值。
    state=
    if [ -n "$CPS_TX_STATUS" ] && [ -r "$CPS_TX_STATUS" ]; then
        IFS= read -r line <"$CPS_TX_STATUS"
        case "$line" in
            *cps_wls_en:1*) state=1 ;;
            *cps_wls_en:0*) state=0 ;;
        esac
    fi
    if [ -z "$state" ] && [ -n "$CPS_PS_ONLINE" ] && [ -r "$CPS_PS_ONLINE" ]; then
        state=$(tr -d '\r' <"$CPS_PS_ONLINE" 2>/dev/null)
    fi
    case "$state" in 0|1) echo "$state" ;; esac
}

cache_hardware_charging() {
    state="$1"
    case "$state" in
        0|1)
            settings put global lenovo_pen_hardware_charge_state "$state" >/dev/null 2>&1
            settings put global lenovo_pen_hardware_charge_valid 1 >/dev/null 2>&1
            # Keep the OEM charging keys in sync with the CPS truth so the
            # Hook handoff cannot override a fresh hardware sample with a
            # stale BLE 2A1A value.
            settings put global lenovo_pen_oem_charge_valid 1 >/dev/null 2>&1
            settings put global lenovo_pen_oem_charge_state "$state" >/dev/null 2>&1
            ;;
    esac
}

read_attached_from_file() {
    file="$1"
    [ -r "$file" ] || return 0
    sed -n 's/^ATTACHED=//p' "$file" 2>/dev/null | head -1 | tr -d '\r'
}

read_hardware_charging() {
    docked="$1"
    if [ "$docked" = 0 ]; then
        # Hall is authoritative for physical charging. CPS ATTACHED and its
        # charge byte can remain latched after removal; never mirror that
        # stale state into the control-center widget or the next capsule.
        cache_hardware_charging 0
        echo 0
        return 0
    fi
    charge_state=$(read_charge_from_file "$CPS_UEVENT")
    attached=$(read_attached_from_file "$CPS_UEVENT")
    case "$charge_state" in
        0|1)
            if [ "$charge_state" = 0 ] || { [ "$attached" = 1 ] || [ "$docked" = 1 ]; }; then
                cache_hardware_charging "$charge_state"
                echo "$charge_state"
                return 0
            fi
            cache_hardware_charging 0
            echo 0
            return 0
            ;;
    esac
    # 本机（sun/SM8750P）的 CPS DT uevent 不带任何键值，上面整块会空转，
    # 于是充电状态只能退到 BLE 记忆值。改从 CPS 收发器 tx_status 取真值。
    # 插在这里而非 UEVENT 之后：两者都是 CPS 硬件路径，该来源比 BLE 记忆
    # 更权威；而本机 lenovo_penraw uevent 只有 MAJOR/MINOR/DEVNAME，取不到
    # 值，所以对 pineapple（其 CPS uevent 带键值、在上面已 return）无影响。
    charge_state=$(read_cps_charging)
    case "$charge_state" in
        0|1)
            cache_hardware_charging "$charge_state"
            echo "$charge_state"
            return 0
            ;;
    esac
    charge_state=$(read_charge_from_file "$UEVENT")
    case "$charge_state" in
        0|1)
            cache_hardware_charging "$charge_state"
            echo "$charge_state"
            return 0
            ;;
    esac
    charge_valid=$(settings get global lenovo_pen_hardware_charge_valid 2>/dev/null | tr -d '\r')
    charge_state=$(settings get global lenovo_pen_hardware_charge_state 2>/dev/null | tr -d '\r')
    if [ "$charge_valid" = 1 ] && { [ "$charge_state" = 0 ] || [ "$charge_state" = 1 ]; }; then
        echo "$charge_state"
        return 0
    fi
    charge_valid=$(settings get global lenovo_pen_oem_charge_valid 2>/dev/null | tr -d '\r')
    charge_state=$(settings get global lenovo_pen_oem_charge_state 2>/dev/null | tr -d '\r')
    if [ "$charge_valid" = 1 ] && { [ "$charge_state" = 0 ] || [ "$charge_state" = 1 ]; }; then
        echo "$charge_state"
    else
        echo 0
    fi
}

is_pen_mac() {
    case "$1" in
        00:00:00:00:00:00) return 1 ;;
        [0-9A-Fa-f][0-9A-Fa-f]:[0-9A-Fa-f][0-9A-Fa-f]:[0-9A-Fa-f][0-9A-Fa-f]:[0-9A-Fa-f][0-9A-Fa-f]:[0-9A-Fa-f][0-9A-Fa-f]:[0-9A-Fa-f][0-9A-Fa-f]) return 0 ;;
        *) return 1 ;;
    esac
}

normalize_pen_mac() {
    raw=$(printf '%s' "$1" | tr -d '\r' | tr 'a-f' 'A-F')
    case "$raw" in
        [0-9A-F][0-9A-F]:[0-9A-F][0-9A-F]:[0-9A-F][0-9A-F]:[0-9A-F][0-9A-F]:[0-9A-F][0-9A-F]:[0-9A-F][0-9A-F])
            printf '%s\n' "$raw"
            ;;
        [0-9A-F][0-9A-F][0-9A-F][0-9A-F][0-9A-F][0-9A-F][0-9A-F][0-9A-F][0-9A-F][0-9A-F][0-9A-F][0-9A-F])
            printf '%s\n' "$raw" | sed 's/../&:/g; s/:$//'
            ;;
        *)
            printf '\n'
            ;;
    esac
}

pen_name_matches() {
    name=$(printf '%s' "$1" | tr -d '\r"' | tr 'A-Z' 'a-z')
    case "$name" in
        *pen*|*stylus*|*pencil*|*lenovo*|*xiaoxin*|*yoga*|*picasso*) return 0 ;;
        *) return 1 ;;
    esac
}

same_pen_mac() {
    left=$(normalize_pen_mac "$1")
    right=$(normalize_pen_mac "$2")
    [ -n "$left" ] && [ "$left" = "$right" ]
}

# Prefer the configured address when it is still a bonded pen. If it is stale,
# select a bonded pen by its advertised name and persist the new address. This
# keeps the Bluetooth path independent of any factory MAC without attempting
# unrelated bonded devices.
find_bonded_pen_mac() {
    preferred=$(normalize_pen_mac "$1")
    for config in \
            /data/misc/bluedroid/bt_config.conf \
            /data/misc/bluetooth/bt_config.conf \
            /data/misc/bluetooth/bt_config.conf.old; do
        [ -r "$config" ] || continue
        best=""
        block_mac=""
        block_name=""
        while IFS= read -r line || [ -n "$line" ]; do
            case "$line" in
                \[*\])
                    block_key=${line#\[}
                    block_key=${block_key%\]}
                    candidate=$(normalize_pen_mac "$block_key")
                    if [ -n "$block_mac" ] && pen_name_matches "$block_name"; then
                        if same_pen_mac "$block_mac" "$preferred"; then
                            printf '%s\n' "$block_mac"
                            return 0
                        fi
                        [ -n "$best" ] || best="$block_mac"
                    fi
                    block_mac="$candidate"
                    block_name=""
                    ;;
                Name=*)
                    block_name=${line#Name=}
                    ;;
            esac
        done <"$config"
        if [ -n "$block_mac" ] && pen_name_matches "$block_name"; then
            if same_pen_mac "$block_mac" "$preferred"; then
                printf '%s\n' "$block_mac"
                return 0
            fi
            [ -n "$best" ] || best="$block_mac"
        fi
        if [ -n "$best" ]; then
            printf '%s\n' "$best"
            return 0
        fi
    done
    printf '\n'
}

resolve_pen_mac() {
    configured=$(normalize_pen_mac "$(settings get global ipe_pencil_mac_addr 2>/dev/null)")
    resolved=$(find_bonded_pen_mac "$configured")
    if ! is_pen_mac "$resolved"; then
        resolved="$configured"
    fi
    if is_pen_mac "$resolved" && ! same_pen_mac "$resolved" "$configured"; then
        settings put global ipe_pencil_mac_addr "$resolved" >/dev/null 2>&1
        echo "[$(date '+%F %T')] selected bonded pen address=$resolved previous=$configured" >&2
    fi
    printf '%s\n' "$resolved"
}

pen_mac_compact() {
    mac=$(resolve_pen_mac)
    printf '%s\n' "$mac" | tr -d ':'
}

request_pen_capsule() {
    [ "$(read_hall_state)" = 1 ] || return 0
    connected=$(settings get global lenovo_pen_link_connected 2>/dev/null | tr -d '\r')
    if [ "$connected" != 1 ]; then
        echo "[$(date '+%F %T')] magnetic capsule delayed: BLE link not ready"
        return 1
    fi
    # 胶囊是「磁吸吸附」这个物理动作的即时反馈，必须在吸附边沿弹出，不能
    # 等一次新鲜油表采样。此前这里硬卡 lenovo_pen_hardware_battery_valid==1，
    # 而该标志恰好在吸附边沿被主动清 0（见 monitor_hall_capsule），本机内核
    # 侧又没有任何新鲜电量源（CPS 路径写错、penraw uevent 无 LEVEL），于是
    # 只能等厂家 BLE 栈推首帧 GATT 样本 —— 实测 10~21 秒，且多次直接超时
    # 不弹。改为：优先新鲜样本，取不到就退化到最后一次真实采样（hook 侧的
    # invalidateHardwareBattery 本来就设计成保留上一次电量可见）。
    battery=$(read_hardware_battery)
    if ! valid_level "$battery"; then
        echo "[$(date '+%F %T')] magnetic capsule delayed: no battery sample yet"
        return 1
    fi
    battery_valid=$(settings get global lenovo_pen_hardware_battery_valid 2>/dev/null | tr -d '\r')
    [ "$battery_valid" = 1 ] || \
        echo "[$(date '+%F %T')] magnetic capsule uses last valid battery=$battery (fresh sample pending)"
    now=$(date '+%s' 2>/dev/null)
    previous=$(cat "$CAPSULE_DEDUP_FILE" 2>/dev/null)
    previous_time=${previous%%:*}
    previous_state=${previous#*:}
    case "$now:$previous_time" in
        *[!0-9:]*|:*) ;;
        *)
            if [ "$previous_state" = 1 ] && [ "$now" -ge "$previous_time" ] \
                    && [ "$((now - previous_time))" -lt "$CAPSULE_DEDUP_SECONDS" ]; then
                echo "[$(date '+%F %T')] duplicate magnetic capsule suppressed"
                return 0
            fi
            ;;
    esac
    charging=$(read_hardware_charging 1)
    mac=$(pen_mac_compact)
    am broadcast --user 0 --receiver-foreground \
        -a com.futureharmony.lenovopenbridge.action.SHOW_PENCIL_CAPSULE \
        -p com.oplus.ipemanager \
        --ei battery_level "$battery" \
        --ei charging_state "$charging" \
        --ei charging "$charging" \
        --es present 1 \
        --es macAddr "$mac" \
        --es source hardware_hall_root >/dev/null 2>&1
    echo "$now:1" >"$CAPSULE_DEDUP_FILE"
    echo "[$(date '+%F %T')] real Hall magnetic capsule requested battery=$battery charging=$charging mac=$mac"
}

request_pen_capsule_when_ready() {
    # 同一个吸附边沿只允许一个重试循环。此前每次 dock 边沿都 fork 一个新
    # worker，而 hall 在吸附瞬间会抖动，再加上开机路径那个延迟 22 秒的
    # worker，常有两三个循环同时存活 —— pen-bridge.log 里成对的重复行就是
    # 它们写的，胶囊也被重复尝试广播。用标记文件去重；任何退出路径都必须
    # 清理，否则会永久堵死后续边沿（服务启动时会先清一次）。
    if [ -e "$CAPSULE_WORKER_FILE" ]; then
        return 0
    fi
    : >"$CAPSULE_WORKER_FILE"
    attempts=0
    while [ "$attempts" -lt 40 ] && [ "$(read_hall_state)" = 1 ]; do
        if request_pen_capsule; then
            rm -f "$CAPSULE_WORKER_FILE"
            return 0
        fi
        attempts=$((attempts + 1))
        sleep_sec 0.5
    done
    rm -f "$CAPSULE_WORKER_FILE"
    echo "[$(date '+%F %T')] magnetic capsule abandoned: link/battery not ready after ${attempts} attempts"
}

publish_hall_state() {
    docked="$1"
    battery=$(read_hardware_battery)
    charging=$(read_hardware_charging "$docked")
    mac=$(pen_mac_compact)
    connected=$(settings get global lenovo_pen_link_connected 2>/dev/null | tr -d '\r')
    [ "$connected" = 1 ] || connected=0

    settings put global lenovo_pen_physical_docked "$docked" >/dev/null 2>&1
    settings put global ipe_pencil_charging_state "$charging" >/dev/null 2>&1
    if valid_level "$battery"; then
        # This is a cache update only after a real sample.  An unavailable
        # CPS/GATT sample must not overwrite the last known level with -1.
        settings put global ipe_pencil_battery_level "$battery" >/dev/null 2>&1
    fi
    refresh_active=0
    if [ "$docked" != 1 ] && [ "$connected" = 1 ]; then
        refresh_active=1
    fi
    # The refresh-rate policy is valid only while writing, but Device Space
    # treats the next two keys as the existence of a connected pen. Do not
    # hide a real Bluetooth device merely because it is magnetically docked.
    settings put global lenovo_pen_refresh_active "$refresh_active" >/dev/null 2>&1
    # OPlusRefreshRatePolicyImpl reads settings_enable_oppo_pencil as
    # isIPEPencilConnected and votes ipePencilRateId (120 Hz) while it is 1.
    # A docked pen is not being written with, so report "pen in use" only
    # when the pen is both connected and off the magnetic dock.
    settings put global settings_enable_oppo_pencil "$refresh_active" >/dev/null 2>&1
    settings put global ipe_pencil_present "$connected" >/dev/null 2>&1

    battery_args=""
    battery_trusted=$(settings get global lenovo_pen_hardware_battery_valid 2>/dev/null | tr -d '\r')
    if valid_level "$battery" && [ "$battery_trusted" = 1 ]; then
        battery_args="--ei battery_level $battery --ei batteryLevel $battery"
        hardware_battery=true
    else
        hardware_battery=false
    fi
    am broadcast --user 0 --receiver-foreground \
        -a com.futureharmony.lenovopenbridge.action.COLOROS_PEN_STATE \
        -p com.oplus.ipemanager \
        $battery_args \
        --ei charging_state "$charging" \
        --ei chargingState "$charging" \
        --ei charging "$charging" \
        --ei physicalDocked "$docked" \
        --es macAddr "$mac" \
        --es name "Lenovo Tab Pen Pro" \
        --es source hardware_hall \
        --ez hardware_battery "$hardware_battery" \
        --ez hardware_identity_known true >/dev/null 2>&1
    echo "[$(date '+%F %T')] real Hall state docked=$docked battery=$battery trusted=$hardware_battery charging=$charging connected=$connected mac=$mac"
}

monitor_battery_cache() {
    while [ ! -e "$CPS_DISABLED" ]; do
        # Before the real HOGP link exists, IPeManager deliberately owns an
        # unknown battery state. Re-injecting a cached level every 10 seconds
        # makes it clear that state again, then restarts the same UI/BT work.
        # Hall-edge publication already preserves the last known value for
        # the capsule; continuous repair begins only after a real link.
        connected=$(settings get global lenovo_pen_link_connected 2>/dev/null | tr -d '\r')
        if [ "$connected" != 1 ]; then
            sleep_sec 10
            continue
        fi
        before=$(settings get global ipe_pencil_battery_level 2>/dev/null | tr -d '\r')
        level=$(read_hardware_battery)
        # The OEM process can publish an unknown sample after the Root boot
        # snapshot. Repair only that cache transition, then let the normal
        # settings receiver consume one valid battery notification.
        if valid_level "$level" && [ "$before" != "$level" ]; then
            docked=$(read_hall_state)
            case "$docked" in
                0|1)
                    publish_hall_state "$docked"
                    echo "[$(date '+%F %T')] invalid battery cache repaired level=$level"
                    ;;
            esac
        fi
        sleep_sec 10
    done
}

monitor_charging_cache() {
    last=$(settings get global lenovo_pen_hardware_charge_state 2>/dev/null | tr -d '\r')
    case "$last" in 0|1) ;; *) last=-1 ;; esac
    while [ ! -e "$CPS_DISABLED" ]; do
        # As with battery repair, avoid fighting IPeManager's disconnected
        # state machine. A Hall edge still publishes the physical dock/charge
        # snapshot once; periodic correction is for an established BLE link.
        connected=$(settings get global lenovo_pen_link_connected 2>/dev/null | tr -d '\r')
        if [ "$connected" != 1 ]; then
            sleep_sec 10
            continue
        fi
        docked=$(read_hall_state)
        case "$docked" in
            0|1)
                charging=$(read_hardware_charging "$docked")
                case "$charging" in
                    0|1)
                        mirrored=$(settings get global ipe_pencil_charging_state 2>/dev/null | tr -d '\r')
                        if [ "$charging" != "$last" ]; then
                            last="$charging"
                            publish_hall_state "$docked"
                            echo "[$(date '+%F %T')] charging state changed charging=$charging mirrored=$mirrored docked=$docked"
                        fi
                        ;;
                esac
                ;;
        esac
        sleep_sec 10
    done
}

# Two-way sync (system Bluetooth -> Device Space). dumpsys masks the first
# four MAC octets, so match the visible last two octets of the pen address
# against the HOGP (LE HID) profile state; HOGP state 2 is a live link.
#
# Split in two on 2026-09-21, after the zombie-reconnect experiment showed the
# old unconditional short-circuit was self-locking (see
# docs/pen_undock_after_dock_sleep_unusable_20260921.md §1.5):
#
#   bt_stack_hogp_live()  - pure stack read, no settings consulted at all.
#   real_bt_connected()   - stack read, vetoed by powered_down *only while the
#                           pen is on the dock*, because that is the only place
#                           the flag can be maintained at all.
#
# The flag is maintained by pen-revive-guard.sh: set when hall=docked and CPS TX
# has been off >= POWERED_DOWN_AFTER_SEC, cleared only when the pen is back on
# the coil (tx=1 || online=1). The pen is *used* away from the dock, so the
# moment it is lifted with the flag at 1 nothing in the design can ever update
# that flag again. Measured 2026-09-21: the pen reconnected and wrote for 6+
# minutes, never docked once, with powered_down pinned at 1 the whole time.
# Letting that stale flag veto the stack read while undocked made
# real_bt_connected() answer "not connected" even though dumpsys already showed
# `hogp connection state=2`, which is precisely why
# request_pen_connect_bounded() logged "reconnect window ended without HOGP" at
# 11:12:23 -- one second after a real session had been torn down and rebuilt --
# and then published lenovo_pen_link_connected=0 over a perfectly live link.
bt_stack_hogp_live() {
    mac=$(resolve_pen_mac)
    is_pen_mac "$mac" || return 1
    tail=${mac#*:*:*:*:}
    case "$tail" in
        *[!0-9A-Fa-f:]*|'') return 1 ;;
    esac
    tail=$(printf '%s' "$tail" | tr 'A-Z' 'a-z')
    # Match one current profile-summary line only. The bluetooth dump also
    # contains connection history; matching the MAC and state independently
    # across the whole dump made a disconnected pen look connected whenever
    # an old "HOGP connection state=2" record was still present.
    dumpsys bluetooth_manager 2>/dev/null \
        | tr 'A-Z' 'a-z' \
        | grep -E "$tail .*hogp connection state=2" >/dev/null 2>&1
}

real_bt_connected() {
    # powered_down 只在笔位于吸附位时有定义（置位与解除条件都要求 docked=1）。
    # 离座后它是结构上无法更新的陈旧值 —— 不得用它否决蓝牙栈的真实状态。
    case "$(settings get global lenovo_pen_physical_docked 2>/dev/null | tr -d '\r')" in
        1)
            case "$(settings get global lenovo_pen_powered_down 2>/dev/null | tr -d '\r')" in
                1) return 1 ;;
            esac
            ;;
    esac
    bt_stack_hogp_live
}

# 笔是否正在线圈上真实响应（CPS 侧带内通信判据）。
# 与 real_bt_connected() 的分工：后者读蓝牙栈，而笔突然掉电时 HOGP state
# 会滞后保持 2（僵尸连接）；本判据读 CPS 内核驱动，与 Hall 磁场边沿同步，
# 实测 TX 关闭时同秒归零（见 docs/pen-sleep-death-analysis.md 的 1 秒序列）。
pen_cps_responsive() {
    [ -n "$CPS_PS_ONLINE" ] && [ -r "$CPS_PS_ONLINE" ] || return 1
    [ "$(tr -d '\r' <"$CPS_PS_ONLINE" 2>/dev/null)" = 1 ]
}

# 笔尖（面板主动笔）活性判据 —— D1a，2026-09-21 实测定型。
#
# 为什么需要它：笔在吸附位满电静置后会自行休眠，但**休眠不拆蓝牙链路**，
# HOGP state 仍为 2。栈于是自认「已连接」，离座边沿的重连决策被吃掉，而笔尖
# 一直不发射 —— 用户表现为「拿下来写不出，必须重新吸附」。
#
# 栈状态与 GATT 探测都回答不了「笔尖还会不会发射」：
#   - 11:31:12 离座那次失败：GATT_CH_OPEN、ACL holders 齐全、HOGP=2，event5 却零事件；
#   - 而健康态的笔同样可以长时间静默（11:34:54 -> 11:38:23 无任何 notify），
#     所以「多久没收到数据」也不能当判据。
# 唯一诚实的是笔尖节点本身：拿起笔总要在屏幕上落笔或悬停。完整证据见
# docs/pen_exp3_v019_failure_20260921.md §13。
PEN_TIP_DEVICE_NAME=NVTCapacitivePen
# 这里曾经是 INPUT_DEVICES_FILE=/proc/bus/input/devices。**不要退回去。**
# 12:21:57 那次真实离座，模块派出去跑 `while IFS= read ... done < 该文件` 的子壳
# 永久卡在 `ppoll(fd=该文件, POLLIN, timeout=NULL)` 上：`/proc/<pid>/fdinfo/0`
# 的读偏移冻结在 `pos: 1`，`/proc/<pid>/syscall` 连续六次采样一字不变。父壳于是
# 永远等不到 `$(pen_tip_event_node)` 的结果，离座分支**既没日志也没重连** ——
# D1a 被静默吃掉，用户看到的仍是「拿下来写不出」。同一个循环在 root shell 里、
# 乃至 `nsenter` 进该进程的挂载命名空间后，都能正常读完 106 行，所以这是与运行时
# 状态相关的偶发阻塞，**不能靠"复现不出来"排除**。节点改用 sysfs 解析（见下）。
# 离座后的活性窗口（秒）。窗口内收到任意笔尖事件即认为发射子系统在工作。
PEN_TIP_ALIVE_WINDOW=2
# 硬重连去重窗口（秒）。Hall 抖动可以在一秒内产生多个离座边沿，而硬重连会
# 真实断开一次笔；没有这层保护就会变成重连风暴。
PEN_HARD_RECONNECT_DEDUP="$MODDIR/pen-hard-reconnect.last"
PEN_HARD_RECONNECT_DEDUP_SECONDS=10

# 硬重连的「OEM 通路不可达」挂起状态（D1a 补丁，v0.1.12，2026-09-21）。
#
# 实测 A/B（同一台机、同一条命令，唯一变量是用户是否解锁过）：
#   未解锁（`dumpsys user` State: RUNNING_LOCKED）
#     cmd package query-services -n com.oplus.ipemanager/.btadsorb.CoreService
#         -> "No services found"（CoreService 与 penhidctl 皆同）
#     am startservice ... -a ...CONNECT_PENCIL
#         -> "Error: Not found; no service started"  (rc=255)
#   解锁后（State: RUNNING_UNLOCKED）同一条命令
#     -> "1 services found" / rc=0，IPeManager 进程随即被拉起
#
# 原因不是 ROM 的 am 缺陷，而是标准 Android 的组件过滤：
# com.oplus.ipemanager 只声明了 PARTIALLY_DIRECT_BOOT_AWARE，
# CoreService 本身不是 direct-boot-aware，用户未解锁时 PMS 在 resolveService
# 阶段就把它滤掉，AMS 于是按「服务不存在」处理。模块自己的
# com.aclaniakea.penhidctl 同样没有该标记（`dumpsys package` 的 flags 里搜不到
# DIRECT_BOOT_AWARE），所以这个窗口里 **OEM 与 HID 两条通路同时不可达** ——
# 发起硬重连只会空转，还会白烧掉去重窗口。
#
# 影响范围（很容易被高估，故写清边界）：RUNNING_LOCKED 只存在于
# **开机 → 该次开机首次解锁**之间。设备只要被解锁过一次，此后即使关屏、
# 进锁屏界面，用户仍是 RUNNING_UNLOCKED。所以用户复现路径
# （吸附 → 锁屏 → 2 分钟 → 解锁 → 取笔书写）**全程处在解锁态，D1a 主路径不受影响**；
# 唯一会撞上的是「开机后首次解锁前」这一小段（实测 11:49 那次启动，模块的
# OEM CONNECT_PENCIL 连失三次；12:03 那次启动，设备在 boot_completed 后约 25 秒
# 进入 RUNNING_UNLOCKED（解锁定位于 12:03:38.5），0.5 秒后同一条调用即成功）。
#
# 设计原则：**先尝试，真的投递失败才延后**。不使用「锁屏状态」之类的代理判据 ——
# 代理判据一旦与真实可达性不符，就会在通路本来可用时拒绝重连，比不修更糟。
# 延后期间等的是**通路恢复（用户解锁）**，不是「用户下笔」：休眠的笔尖节点本就
# 零事件（那正是 D1a 判据本身），拿笔尖活性当恢复触发器会永远等不到触发。
PEN_PENDING_RECONNECT="$MODDIR/pen-hard-reconnect.pending"
PEN_PENDING_RECONNECT_PID="$MODDIR/pen-hard-reconnect.pending.pid"
# 单实例锁（目录）。mkdir 是原子的，用来保证同一时刻只有一个等待者。
PEN_PENDING_RECONNECT_LOCK="$MODDIR/pen-hard-reconnect.pending.lock"
# 挂起等待的上限（秒）。超过就放弃，避免一个永不来的解锁把进程留在后台。
PEN_PENDING_RECONNECT_TTL=1800

# 按【设备名】解析笔尖的 evdev 节点。
#
# 两条硬约束：
#   1) 必须用名字而不是节点号：硬重连后蓝牙 HID 设备会重新枚举（实测 10/11 -> 12/13），
#      任何写死的节点号都会在重连后立刻失效。另注意 `dumpsys input` 里的设备 id
#      （如 "9: NVTCapacitivePen"）并不是 evdev 节点号 —— 本机该设备实际挂在 event5。
#   2) **不得读 /proc/bus/input/devices**（原因见上方 INPUT_DEVICES_FILE 处的注释）。
#      改扫 sysfs：`/sys/class/input/inputN/name` 找名字，`inputN/eventM` 拿节点。
#      这条通路与小文件单次读同源，正是 `read_hall_state()` 已连续稳定工作数小时的
#      那条；不经过 procfs，也不再用 shell 的 `read` 内建去遍读一个 procfs 大文件。
# 实测（12:3x，设备）：匹配 input8 -> event5 -> 输出 `/dev/input/event5`。
pen_tip_event_node() {
    for pen_tip_input in /sys/class/input/input*; do
        [ -r "$pen_tip_input/name" ] || continue
        pen_tip_name=$(cat "$pen_tip_input/name" 2>/dev/null)
        [ "$pen_tip_name" = "$PEN_TIP_DEVICE_NAME" ] || continue
        for pen_tip_ev in "$pen_tip_input"/event*; do
            [ -e "$pen_tip_ev" ] || continue
            case "${pen_tip_ev##*/}" in
                event[0-9]*) ;;
                *) continue ;;
            esac
            # `inputN/eventM` 是 sysfs 目录，字符设备在 /dev/input/ 下；
            # 直接截取 basename 会得到 /dev/event5（少一层 input/），别那么写。
            printf '%s\n' "/dev/input/${pen_tip_ev##*/}"
            return 0
        done
    done
    return 1
}

# 笔尖在窗口内是否产生过事件。三态返回，务必区分「没事件」与「判不了」——
# 把工具故障当成休眠会导致每次离座都无谓重连：
#   0 = 有事件（笔在发射，健康）
#   1 = 窗口内零事件（疑似发射子系统休眠，应硬重连）
#   2 = 无法判定（设备节点不存在、工具不可用等）
# 调用方（离座分支）对 1 与 2 **都**发起硬重连：2 的每一种成因都指向「拿不到
# 笔尖输入」这个同一事实（节点不存在 = 笔根本没在提供输入；工具不可用 = 探针
# 失效），而硬重连是唯一可用的杠杆，代价只有一次 ~2 秒的断连。
#
# v0.1.16（2026-09-21）：判定改为**只看输出里有没有事件行**，不再看退出码。
#   退出码是竞态的。13:12:27 那次真实离座，模块记下 `getevent rc=143`
#   （128+SIGTERM）；13:24 我拿同一条命令、同一个节点实测，得到 `rc=124`
#   （toybox 的正常超时码）。二进制没变（/system/bin/timeout -> toybox 0.8.12）、
#   节点没变，差异只可能来自「timeout 发信号」与「getevent 自己退出」的赛跑：
#   子进程的退出状态先被谁结算，父进程就报谁。于是同一种物理事实（窗口内零
#   事件）会随机落到 124 或 143 两个分支上。旧代码把 143 归进 `*)` 判成「无法
#   判定」，平白多打一条误导性日志；更糟的是，若某个工具版本的超时码变成 137
#   或 1，「决策」就会被退出码悄悄改写 —— 而这本该只由「笔有没有发射」决定。
#   改成读输出后，判据只依赖"有没有 EVENT 行"这一个物理事实，与退出码、工具
#   版本、信号竞态全部解耦。
pen_tip_alive_within() {
    pen_tip_window="$1"
    pen_tip_node=$(pen_tip_event_node)
    if [ -z "$pen_tip_node" ]; then
        # 离座那一秒笔的 HID 输入设备正在按序注销/重建（实测 sysfs 里会新冒出
        # "Lenovo Tab Pen Pro 2 Mouse" / "Consumer Control" 两个 inputN），节点
        # 可能刚好扫不到。等 1 秒重试一次再下结论，免得把「正在重建」误报成
        # 「判不了」而多断一次链。窗口从重试之后开始计。
        sleep_sec 1
        pen_tip_node=$(pen_tip_event_node)
    fi
    if [ -z "$pen_tip_node" ]; then
        echo "[$(date '+%F %T')] tip probe: no $PEN_TIP_DEVICE_NAME evdev node in sysfs (pen input devices mid-rebuild?)"
        return 2
    fi
    if [ ! -r "$pen_tip_node" ]; then
        echo "[$(date '+%F %T')] tip probe: node $pen_tip_node not readable"
        return 2
    fi
    # `-l` 让输出带事件名（"EV_ABS ABS_X ..."）—— 只有这个格式里才有 "EV_" 这个
    # 可比对的锚点；不带 -l 时 getevent 打的是十六进制单行，没法认。`2>&1` 把
    # getevent 自己的报错一并收进变量，好在下面把「静默」和「工具报错」分开。
    pen_tip_out=$(timeout "$pen_tip_window" getevent -l -c 1 "$pen_tip_node" 2>&1)
    if [ -z "$pen_tip_out" ]; then
        # 窗口内零输出 = 窗口内零事件。这正是「笔没在发射」的诚实读数，
        # 也正是离座瞬间的常态（用户此刻还没落笔）。
        return 1
    fi
    case "$pen_tip_out" in
        *EV_*) return 0 ;;
        *)
            echo "[$(date '+%F %T')] tip probe: getevent gave no event line on $pen_tip_node: $(printf '%s' "$pen_tip_out" | tr '\n' ' ' | cut -c1-120)"
            return 2
            ;;
    esac
}

# ---- 探针看门狗（v0.1.14，2026-09-21）------------------------------------
#
# 离座分支把活性判定放进后台子壳（窗口要 2 秒，不能阻塞 Hall 监视循环），
# 而 `( ... ) &` 的失败语义是**静默**：子壳若自己卡住，就既没有日志也没有重连，
# D1a 整个消失 —— 12:21:57 那次真实离座正是如此（详见上方 INPUT_DEVICES_FILE
# 处记录的证据）。所以由监视循环自己记账：派出去时记 PID 与起始秒，此后每秒
# 确认它还活着；超过上限即收尸，并**改为直接硬重连**。
#
# 取舍：宁可多断一次链（~2 秒）也不能让一次卡死换来一支写不出的笔。
# 被 kill 的子壳若已派生更深的卡死进程，那些孤儿仍会挂着（阻塞态，不耗 CPU），
# 重启即清；这与「整条恢复通路永久哑掉」相比是可接受的代价。
# 上限取 15 秒，而不是「窗口 + 5」。因为同一个记账槽也用于「栈链路已断」那条
# 快速通路（它直接跑 request_pen_reconnect_hard）。一次完整硬重连最长会包含
# 6 秒的 HOGP 落下等待 + am 投递开销 + 连接，约 10 秒；上限若贴得太近，看门狗
# 会把**正在进行**的重连当成卡死再补一刀。多出来的那一次由 10 秒去重兜住
# （会打印 "hard reconnect skipped: previous one ran Ns ago"），不会变成风暴。
PEN_TIP_PROBE_MAX=15
PEN_TIP_PROBE_PID=""
PEN_TIP_PROBE_STARTED=0

pen_tip_probe_reap() {
    [ -n "$PEN_TIP_PROBE_PID" ] || return 0
    if ! kill -0 "$PEN_TIP_PROBE_PID" 2>/dev/null; then
        # 正常退出（已自行判定并打过日志）。
        PEN_TIP_PROBE_PID=""
        return 0
    fi
    pen_tip_probe_now=$(date '+%s' 2>/dev/null)
    case "$pen_tip_probe_now" in ''|*[!0-9]*) return 0 ;; esac
    [ "$PEN_TIP_PROBE_STARTED" -gt 0 ] || return 0
    pen_tip_probe_age=$((pen_tip_probe_now - PEN_TIP_PROBE_STARTED))
    [ "$pen_tip_probe_age" -ge "$PEN_TIP_PROBE_MAX" ] || return 0
    echo "[$(date '+%F %T')] WARN pen tip probe wedged ${pen_tip_probe_age}s (pid=$PEN_TIP_PROBE_PID, limit=${PEN_TIP_PROBE_MAX}s); killing it and forcing hard reconnect"
    kill -9 "$PEN_TIP_PROBE_PID" 2>/dev/null
    PEN_TIP_PROBE_PID=""
    # 后台执行：重连最长会等 HOGP 落下 6 秒，不能阻塞 Hall 监视循环。
    ( request_pen_reconnect_hard ) &
    return 1
}

# 用户是否已解锁。仅用于把失败原因写清楚（诊断），**不参与任何决策** ——
# 决策一律以真实的 am 投递结果为准，见 PEN_PENDING_RECONNECT 的设计原则。
# 实测 `dumpsys user` 单次约 13ms。
user_unlocked() {
    dumpsys user 2>/dev/null | grep -q 'State: RUNNING_UNLOCKED'
}

# 挂起等待者：等 OEM/HID 通路重新可用时再试一次硬重连。
#
# 触发条件为什么是「用户解锁」而不是「用户下笔」：**休眠的笔尖节点本就零事件**
# —— 那正是 D1a 判据本身。用笔尖活性当触发器会永远等不到触发（死锁）。而
# 解锁是通路恢复的充分条件，且每次开机只发生一次，语义干净。
#
# 重试安全性：通路不可达时，硬重连在第一步的 OEM 投递就失败并原样返回，
# 不产生任何副作用（不会先断链），所以这里的周期性重试不会变成重连风暴；
# 一旦首次投递成功，函数会一路走完并清掉 pending，本循环随即退出。
wait_writable_then_hard_reconnect() {
    pen_pending_waited=0
    while [ "$pen_pending_waited" -lt "$PEN_PENDING_RECONNECT_TTL" ]; do
        sleep_sec 5
        pen_pending_waited=$((pen_pending_waited + 5))
        # pending 被清掉说明重连已成功（或用户主动断开），收工。
        [ -e "$PEN_PENDING_RECONNECT" ] || break
        user_unlocked || continue
        echo "[$(date '+%F %T')] deferred pen hard reconnect firing after ${pen_pending_waited}s"
        request_pen_reconnect_hard
    done
    rm -f "$PEN_PENDING_RECONNECT_PID"
    rmdir "$PEN_PENDING_RECONNECT_LOCK" 2>/dev/null
    if [ -e "$PEN_PENDING_RECONNECT" ]; then
        rm -f "$PEN_PENDING_RECONNECT"
        echo "[$(date '+%F %T')] deferred pen hard reconnect gave up after ${pen_pending_waited}s (OEM channel never became reachable)"
    else
        echo "[$(date '+%F %T')] deferred pen hard reconnect watcher exit after ${pen_pending_waited}s"
    fi
}

# 同一时刻只允许一个挂起等待者：Hall 抖动或反复下笔会重复触发延后路径。
#
# 单实例用 `mkdir` 的原子性保证，不用「读 pidfile 再判断进程存活」—— 后者要
# 靠 /proc/<pid>/cmdline 里出现本脚本名来排除「PID 已被回收给别的进程」，
# 桩测试实测这层判断很脆（换一个脚本名去重就整体失效）。持有者死掉时
# （模块重启、被 OOM 杀掉）后来者会接管锁，因此不会永久卡死。
spawn_deferred_hard_reconnect() {
    if mkdir "$PEN_PENDING_RECONNECT_LOCK" 2>/dev/null; then
        ( wait_writable_then_hard_reconnect ) &
        echo $! >"$PEN_PENDING_RECONNECT_PID"
        return 0
    fi
    pen_pending_owner=$(cat "$PEN_PENDING_RECONNECT_PID" 2>/dev/null)
    case "$pen_pending_owner" in
        ''|*[!0-9]*) ;;
        *) kill -0 "$pen_pending_owner" 2>/dev/null && return 0 ;;
    esac
    echo "[$(date '+%F %T')] deferred hard reconnect watcher gone; taking over the lock"
    rmdir "$PEN_PENDING_RECONNECT_LOCK" 2>/dev/null
    spawn_deferred_hard_reconnect
}

# 笔在用时的 120Hz 由原厂 OplusRefreshRatePolicyImpl 依据
# settings_enable_oppo_pencil 自行投票；本模块不读取或写入用户的
# system min_refresh_rate / peak_refresh_rate。

# The OEM mirrors can lag or be overridden by a stale disconnect latch. Poll
# the actual Bluetooth stack at low rate and republish the connection
# mirrors so Device Space always follows the real link. If a live link appears
# while a stale user-disconnect latch is still set, the stack has already
# reconnected: clear the latch so the UI stops reporting "disconnected".
# 用户在设置页或设备空间点「断开连接」/「立即连接」之后，真实 ACL 链路需要
# 一到三秒才跟上。Hook 会同时写下意图目标与时间戳；在收敛窗口内对账器既不
# 改写连接镜像，也不清 user latch。否则它会把用户半秒前刚表达的意图当成
# 「陈旧闩锁」清掉，自动重连随即把 UI 翻回已连接，表现为反复横跳。
PEN_USER_ACTION_GRACE=8

in_user_action_window() {
    real_state="$1"
    ts=$(settings get global lenovo_pen_user_action_ts 2>/dev/null | tr -d '\r')
    target=$(settings get global lenovo_pen_user_action_target 2>/dev/null | tr -d '\r')
    case "$ts" in ''|*[!0-9]*) return 1 ;; esac
    case "$target" in 0|1) ;; *) return 1 ;; esac
    # 真实链路已经追上用户意图：立即退出窗口，恢复正常对账。
    [ "$real_state" = "$target" ] && return 1
    now=$(date '+%s' 2>/dev/null)
    case "$now" in ''|*[!0-9]*) return 1 ;; esac
    # 时钟回拨时按窗口外处理，避免窗口被拉长到不确定的时间。
    [ "$now" -lt "$ts" ] && return 1
    [ "$((now - ts))" -lt "$PEN_USER_ACTION_GRACE" ]
}

monitor_real_bt_state() {
    last=-1
    last_oem_recovery=0
    oem_recovery_attempts=0
    oem_recovery_exhausted=0
    # 「投递不出去」的独立计数：未解锁 / 包未登记时的失败不消耗 3 次尝试预算。
    oem_recovery_blocked=0
    while [ ! -e "$CPS_DISABLED" ]; do
        if real_bt_connected; then
            connected=1
        else
            connected=0
        fi
        # 用户刚操作过且链路尚未收敛：本轮完全不发布，只快速重采样。
        # 这是有界的（PEN_USER_ACTION_GRACE 秒），收敛后立即回到 30 秒低频对账，
        # 不会变成常驻 1Hz 轮询。
        if in_user_action_window "$connected"; then
            sleep_sec 1
            continue
        fi
        current=$(settings get global lenovo_pen_link_connected 2>/dev/null | tr -d '\r')
        [ "$current" = 1 ] || current=0
        if [ "$connected" != "$current" ] || [ "$connected" != "$last" ]; then
            settings put global lenovo_pen_link_connected "$connected" >/dev/null 2>&1
            # OPlusRefreshRateService treats ipe_pencil_connect_state==1 as the
            # IPE pencil connected (isIPEPencilConnected) and votes the OEM
            # ipePencilRateId (120 Hz) while connected. The other mirror keys
            # keep the legacy connected encoding for the pen settings UI.
            connect_state=0
            [ "$connected" = 1 ] && connect_state=2
            for key in ipe_pencil_connection_state PENCIL_CONNECT_STATE pencil_connect_state; do
                settings put global "$key" "$connect_state" >/dev/null 2>&1
            done
            settings put global ipe_pencil_connect_state "$connected" >/dev/null 2>&1
            docked=$(settings get global lenovo_pen_physical_docked 2>/dev/null | tr -d '\r')
            [ "$docked" = 1 ] || docked=0
            pen_in_use=0
            [ "$connected" = 1 ] && [ "$docked" != 1 ] && pen_in_use=1
            settings put global settings_enable_oppo_pencil "$pen_in_use" >/dev/null 2>&1
            settings put global ipe_pencil_present "$connected" >/dev/null 2>&1
            if [ "$connected" = 1 ]; then
                user_requested=$(settings get global lenovo_pen_user_disconnect_requested 2>/dev/null | tr -d '\r')
                if [ "$user_requested" = 1 ]; then
                    settings put global lenovo_pen_user_disconnect_requested 0 >/dev/null 2>&1
                    settings put global lenovo_pen_disconnect_requested 0 >/dev/null 2>&1
                    echo "[$(date '+%F %T')] real BT link present; cleared stale disconnect latch"
                fi
            fi
            # Push the real link to the OEM UI: the Hook's handoff receiver
            # consumes the connected extra and forwards it to the panel and
            # settings callbacks, so a sheet opened before the link came up
            # stops showing a stale "connecting/disconnected" state.
            battery=$(settings get global ipe_pencil_battery_level 2>/dev/null | tr -d '\r')
            valid_level "$battery" || battery=$(settings get global lenovo_pen_last_valid_battery 2>/dev/null | tr -d '\r')
            charging=$(settings get global lenovo_pen_hardware_charge_state 2>/dev/null | tr -d '\r')
            case "$charging" in 0|1) ;; *) charging=0 ;; esac
            mac=$(pen_mac_compact)
            am broadcast --user 0 --receiver-foreground \
                -a com.futureharmony.lenovopenbridge.action.COLOROS_PEN_STATE \
                -p com.oplus.ipemanager \
                --ei connected "$connected" \
                --ei battery_level "$battery" \
                --ei charging_state "$charging" \
                --es present "$connected" \
                --es macAddr "$mac" \
                --es source hardware_hall >/dev/null 2>&1
            echo "[$(date '+%F %T')] real BT state mirror connected=$connected (was $current)"
            # A new physical ACL/HOGP session is the only sound reason to
            # retry OEM GATT-session recovery.  Do not carry a failed budget
            # across a genuine disconnect/reconnect edge.
            oem_recovery_attempts=0
            oem_recovery_exhausted=0
            oem_recovery_blocked=0
            last_oem_recovery=0
            last="$connected"
        fi
        if [ "$connected" = 1 ] \
                && [ "$(settings get global lenovo_pen_oem_control_ready 2>/dev/null | tr -d '\r')" != 1 ] \
                && [ "$(settings get global lenovo_pen_disconnect_requested 2>/dev/null | tr -d '\r')" != 1 ]; then
            now=$(date '+%s' 2>/dev/null)
            case "$now:$last_oem_recovery" in
                *[!0-9:]*|:*) ;;
                *)
                    if [ "$oem_recovery_attempts" -lt 3 ] \
                            && [ "$now" -ge "$last_oem_recovery" ] \
                            && [ "$((now - last_oem_recovery))" -ge 30 ]; then
                        last_oem_recovery="$now"
                        # 投递失败（未解锁、包还没登记）不消耗 3 次尝试预算：那与
                        # 「原厂接收方拒绝了活链路」是两回事。开机后到首次解锁之间
                        # 必然不可达，旧实现把三次预算全烧在这里，然后一直等到下一次
                        # 真实蓝牙边沿才恢复 OEM 会话（实测 12:09 那次启动：attempt
                        # 1/3、2/3 全是 unlocked=0）。这里改成预算只记「真投出去」的
                        # 次数，投递不出去的另行计数并封顶，避免无限重试。
                        if request_oem_pen_action "$OEM_CONNECT_ACTION"; then
                            oem_recovery_attempts=$((oem_recovery_attempts + 1))
                            echo "[$(date '+%F %T')] live HOGP missing OEM haptic session; recovery requested attempt=$oem_recovery_attempts/3"
                        else
                            oem_recovery_blocked=$((oem_recovery_blocked + 1))
                            echo "[$(date '+%F %T')] OEM haptic recovery not deliverable; channel unreachable, budget kept (${oem_recovery_blocked}/40)"
                            if [ "$oem_recovery_blocked" -ge 40 ]; then
                                oem_recovery_exhausted=1
                                echo "[$(date '+%F %T')] OEM haptic recovery deferred until next real BT link edge"
                            fi
                        fi
                    elif [ "$oem_recovery_attempts" -ge 3 ] && [ "$oem_recovery_exhausted" = 0 ]; then
                        # The OEM receiver rejected a live link repeatedly.
                        # Retrying forever turns a missing optional session
                        # into a 30-second Bluetooth/system_server CPU spike.
                        # The direct GATT haptic path remains available; try
                        # OEM recovery again only after a real link edge.
                        oem_recovery_exhausted=1
                        echo "[$(date '+%F %T')] OEM haptic recovery deferred until next real BT link edge"
                    fi
                    ;;
            esac
        fi
        # Real ACL/GATT callbacks update the mirror immediately.  Keep this
        # expensive full bluetooth_manager dump as a low-rate reconciliation
        # path only, not a one-Hz permanent poll.
        trim_log_if_large
        sleep_sec 30
    done
}

monitor_hall_capsule() {
    candidate=-1
    samples=0
    boot_cycle=1
    last=$(cat "$HALL_STATE_FILE" 2>/dev/null | tr -d '\r')
    case "$last" in 0|1) ;; *) last=-1 ;; esac
    while [ ! -e "$CPS_DISABLED" ]; do
        # 先收尸再采样：上一次离座派出去的活性探针若卡死，这里负责发现并
        # 强制重连（见 pen_tip_probe_reap）。正常时它只花一次 kill -0。
        pen_tip_probe_reap
        state=$(read_hall_state)
        case "$state" in
            0|1)
                if [ "$state" = "$candidate" ]; then
                    samples=$((samples + 1))
                else
                    candidate="$state"
                    samples=1
                fi
                if [ "$samples" -ge 2 ]; then
                    # Do not republish solely because a receiver has not yet
                    # mirrored the setting. That feedback loop generated
                    # repeated system_server broadcasts every poll interval.
                    if [ "$boot_cycle" = 1 ] || [ "$state" != "$last" ]; then
                        previous="$last"
                        last="$state"
                        echo "$state" >"$HALL_STATE_FILE"
                        if [ "$state" = 1 ] && [ "$previous" != 1 ]; then
                            # A dock edge starts a new pen power session. Do
                            # not let the previous session's cached battery
                            # satisfy this attach's capsule readiness check.
                            settings put global lenovo_pen_hardware_battery_valid 0 >/dev/null 2>&1
                        fi
                        publish_hall_state "$state"
                        if [ "$state" = 1 ]; then
                            # Magnetic attach is a physical reconnect intent:
                            # clear any stale disconnect latch and restore the
                            # link if it is not already up at the BT layer.
                            settings put global lenovo_pen_user_disconnect_requested 0 >/dev/null 2>&1
                            settings put global lenovo_pen_disconnect_requested 0 >/dev/null 2>&1
                            # 吸附边沿 = 一次全新的物理会话。这里不能只看
                            # real_bt_connected()：笔上一轮满电掉电后蓝牙栈的
                            # HOGP state 会滞留为 2（僵尸连接），判据恒真就会
                            # 吃掉这次重连请求 —— 表现正是「吸上去是死的，必须
                            # 再吸一次」。补一层 CPS 判据：笔没在线圈上真实响应
                            # 时必须重连，不管蓝牙栈怎么说。
                            # request_pen_connect 自带 8 秒去重，Hall 抖动不会
                            # 变成重连风暴。
                            if ! real_bt_connected || ! pen_cps_responsive; then
                                request_pen_connect
                            fi
                            if [ "$boot_cycle" = 1 ]; then
                                # IPeManager's BLE process registers the
                                # dynamic Capsule receiver late in boot. Do
                                # not spend the only boot request before it
                                # exists; the real Hall state is already
                                # published above.
                                (
                                    sleep_sec 22
                                    request_pen_capsule_when_ready
                                ) &
                            else
                                request_pen_capsule_when_ready &
                            fi
                        elif [ "$state" = 0 ] && [ "$previous" = 1 ]; then
                            # 离开吸附位：关闭吸附胶囊。
                            am broadcast --user 0 --receiver-foreground \
                                -a com.futureharmony.lenovopenbridge.action.DISMISS_PENCIL_CAPSULE \
                                -p com.oplus.ipemanager >/dev/null 2>&1
                            # 离座边沿的重连决策（D1a，2026-09-21 实测定型）。
                            #
                            # 旧实现挂在两个**同时失效**的条件后面：`powered_down=1`
                            # 要求笔在座上静置满 POWERED_DOWN_AFTER_SEC(=90) 秒才置位，
                            # 而实测失败只需 47 秒；`! real_bt_connected` 在僵尸连接下
                            # 恒假。结果离座边沿**一个动作都不发**，笔保持休眠 ——
                            # 11:31 实测 pen-bridge.log 在 `real Hall state docked=0`
                            # 之后再无任何输出，全程零重连尝试。
                            #
                            # 现在只看两件事，且都放后台（活性窗口要 2 秒，不能阻塞
                            # Hall 监视循环）：
                            #   1) 蓝牙栈链路真的不在 -> 直接硬重连，不必等窗口；
                            #   2) 栈说「在」，但它可能是僵尸 -> 用笔尖活性判据裁决。
                            # 判据诚实的原因：拿起笔总要在屏幕上落笔或悬停，窗口内
                            # 零事件就说明笔没在发射，此时唯一的恢复手段是先断后连。
                            # 实测（§13）：破链重连后笔在**全程未吸附**的情况下正常书写。
                            #
                            # v0.1.14 的两处加固：
                            #   (1) 两个后台子壳都登记 PID + 起始秒，监视循环每秒确认
                            #       它们还活着；卡死会被 pen_tip_probe_reap 收尸并强制
                            #       重连。原因见 PEN_TIP_PROBE_MAX 处 —— `( ... ) &`
                            #       的失败是静默的，12:21:57 就是这样把 D1a 整条吃掉。
                            #   (2) 3 态里的「无法判定」(rc=2) 从「不动」改为「重连」：
                            #       拿不到笔尖输入这件事本身就需要重连，而静默不动正是
                            #       用户报的那个 bug。两次判定都会留下日志，不再有
                            #       「离座后模块零输出」这种状态。
                            if ! bt_stack_hogp_live; then
                                echo "[$(date '+%F %T')] undock: stack link not live; hard reconnecting without waiting for probe"
                                ( request_pen_reconnect_hard ) &
                                PEN_TIP_PROBE_PID=$!
                                PEN_TIP_PROBE_STARTED=$(date '+%s' 2>/dev/null)
                                case "$PEN_TIP_PROBE_STARTED" in ''|*[!0-9]*) PEN_TIP_PROBE_STARTED=0 ;; esac
                            else
                                (
                                    pen_tip_alive_within "$PEN_TIP_ALIVE_WINDOW"
                                    pen_tip_state=$?
                                    case "$pen_tip_state" in
                                        1)
                                            echo "[$(date '+%F %T')] pen tip silent for ${PEN_TIP_ALIVE_WINDOW}s after undock; assuming sleeping emitter"
                                            request_pen_reconnect_hard
                                            ;;
                                        0)
                                            echo "[$(date '+%F %T')] pen tip alive after undock; link kept"
                                            ;;
                                        *)
                                            echo "[$(date '+%F %T')] pen tip liveness unknown (rc=${pen_tip_state}); hard reconnecting as fail-safe"
                                            request_pen_reconnect_hard
                                            ;;
                                    esac
                                ) &
                                PEN_TIP_PROBE_PID=$!
                                PEN_TIP_PROBE_STARTED=$(date '+%s' 2>/dev/null)
                                case "$PEN_TIP_PROBE_STARTED" in ''|*[!0-9]*) PEN_TIP_PROBE_STARTED=0 ;; esac
                            fi
                        fi
                    fi
                    boot_cycle=0
                fi
                ;;
        esac
        sleep_sec 1
    done
}

run_hidctl() {
    action="$1"
    mac=$(resolve_pen_mac)
    if ! is_pen_mac "$mac"; then
        echo "[$(date '+%F %T')] HID $action skipped: no bonded pen MAC"
        return 0
    fi
    if [ -z "$(pm path com.aclaniakea.penhidctl 2>/dev/null)" ]; then
        echo "[$(date '+%F %T')] HID $action skipped: helper APK unavailable"
        return 0
    fi
    grant_hidctl_bluetooth_permissions
    if am start-foreground-service --user 0 -n "$HIDCTL_SERVICE" \
            --es action "$action" --es mac "$mac" >/dev/null 2>&1; then
        echo "[$(date '+%F %T')] HID $action service requested mac=$mac"
    else
        echo "[$(date '+%F %T')] HID $action request failed mac=$mac"
    fi
}

request_oem_pen_action() {
    action="$1"
    mac=$(resolve_pen_mac)
    if ! is_pen_mac "$mac"; then
        echo "[$(date '+%F %T')] OEM $action skipped: no bonded pen MAC"
        return 0
    fi
    if [ -z "$(pm path com.oplus.ipemanager 2>/dev/null)" ]; then
        # 「包还不在 PMS 视野里」（开机早期 priv-app 尚未登记，实测 12:08:55
        # 那几次 `pm path` 全空）也不等于投递成功：调用方若据此认为 OEM 通路
        # 可用，就会在只有 HID 半边可用的时候先断链。硬重连把它当失败，延后
        # 重试；其它调用方本来就不看返回值，行为不变。
        echo "[$(date '+%F %T')] OEM $action unavailable: IPeManager not registered yet"
        return 1
    fi
    # These are the vendor service's real actions.  CONNECT_PENCIL reaches
    # s0.x()/BleManager.b(), while DISCONNECT_PENCIL reaches s0.z() and the
    # hidden BluetoothDevice.disconnect() path.  The old Root service only
    # sent a custom system_server broadcast, which could not close/open the
    # OEM GATT link.
    extra=""
    if [ "$action" = "$OEM_CONNECT_ACTION" ]; then
        extra="--ez codex_auto_connect true"
    fi
    if am startservice --user 0 -n "$OEM_CORE_SERVICE" \
            -a "$action" --es device_mac_info "$mac" $extra >/dev/null 2>&1; then

        echo "[$(date '+%F %T')] OEM $action requested mac=$mac"
        return 0
    fi
    # 失败有三种成因，调用方按返回值决定是否延后（硬重连会，其它调用忽略）：
    #   1) 用户未解锁 -> PMS 过滤掉非 direct-boot-aware 的 CoreService，
    #      am 报 "Error: Not found; no service started" (rc=255)；
    #   2) 以 shell(uid 2000) 身份调用 -> "Requires permission
    #      com.oplus.permission.safe.IOT"。模块以 root(uid 0) 运行，不受此限；
    #   3) 包尚未进入 PMS（开机早期 priv-app 未登记）-> 上面的 pm path 判空。
    echo "[$(date '+%F %T')] OEM $action request failed mac=$mac unlocked=$(user_unlocked && echo 1 || echo 0)"
    return 1
}

request_pen_connect() {
    requested=$(settings get global lenovo_pen_disconnect_requested 2>/dev/null | tr -d '\r')
    [ "$requested" = 1 ] && {
        echo "[$(date '+%F %T')] pen connect skipped: Settings disconnect latch is set"
        return 0
    }
    user_requested=$(settings get global lenovo_pen_user_disconnect_requested 2>/dev/null | tr -d '\r')
    [ "$user_requested" = 1 ] && {
        echo "[$(date '+%F %T')] pen connect skipped: user disconnect choice is active"
        return 0
    }

    now=$(date '+%s' 2>/dev/null)
    previous=$(cat "$PEN_CONNECT_DEDUP_FILE" 2>/dev/null)
    case "$previous" in
        ''|*[!0-9]*) ;;
        *)
            [ "$now" -ge "$previous" ] && [ "$((now - previous))" -lt 8 ] && return 0
            ;;
    esac
    echo "$now" >"$PEN_CONNECT_DEDUP_FILE"
    request_oem_pen_action "$OEM_CONNECT_ACTION"
    # Let the stock CoreService create the BLE/GATT session before asking the
    # hidden HID Host profile to attach to the same bonded device. The panel
    # is forced to the real link state by the Hook, so this wait only needs
    # to cover the OEM GATT session, not the full UI round-trip.
    sleep_sec 1
    run_hidctl connect
}

# The Settings reconnect button must remain a bounded user action, but a
# single HID request can race the OEM GATT service while the pen is waking.
# Retry HID Host only (the original CoreService session stays authoritative)
# and stop immediately when the current HOGP summary reports state 2.
request_pen_connect_bounded() {
    request_pen_connect
    (
        retry=1
        while [ "$retry" -le 3 ] && [ ! -e "$CPS_DISABLED" ]; do
            sleep_sec 3
            if real_bt_connected; then
                echo "[$(date '+%F %T')] explicit pen reconnect confirmed by HOGP attempt=$retry"
                exit 0
            fi
            run_hidctl connect
            echo "[$(date '+%F %T')] explicit pen HID retry attempt=$retry"
            retry=$((retry + 1))
        done
        echo "[$(date '+%F %T')] explicit pen reconnect window ended without HOGP"
        # 三次普通 connect 都被拒，最常见的原因就是僵尸连接：HOGP 滞留在 2，
        # 蓝牙栈于是拒绝一切新的 connect。此时再重复普通 connect 没有意义，
        # 兜底走一次硬重连（先断后连）—— 实测这是唯一能破除僵尸的手段。
        request_pen_reconnect_hard
    ) &
}

request_pen_disconnect() {
    request_oem_pen_action "$OEM_DISCONNECT_ACTION"
    run_hidctl disconnect
}

# 僵尸连接的硬破除：先 DISCONNECT 再 CONNECT。
#
# 场景（2026-09-21 实测复现）：笔在吸附位满电静置 -> CPS 关 TX -> 笔自行休眠，
# 但蓝牙栈把 HOGP state 滞留在 2。此时栈自认「已连接」，任何新的 connect 都被
#   E/HidHostService: Device XX:...:77:DD not disconnected. state=2
# 直接拒绝（原话，11:02:09.528 与 11:11 之前均为同一形态）。模块原来的普通
# request_pen_connect 因此永远打不通，用户只能靠重新吸附（由笔侧发起新链路）绕开 ——
# 这正是「吸附充电锁屏后拿下来用不了，必须重新吸附」的机制。
#
# 实测破除效果（root，零用户操作，笔全程未吸附）：
#   DISCONNECT 之后 hogp state 2 -> 3 -> 0（< 2 秒）
#   CONNECT   之后 6 秒内完整会话重建：services=12 characteristics=36、
#             固件 PARKER-V3 V1.26、序列号 HVE70MYJ、电量 100%、notify 正常回包、
#             Hook 侧 "real HID connected: pen input gate restored"。
#   11:02 的 CONNECT 失败与 11:12 的成功，唯一差异就是中间插了这次 DISCONNECT。
request_pen_reconnect_hard() {
    prior=$(settings get global lenovo_pen_disconnect_requested 2>/dev/null | tr -d '\r')
    if [ "$prior" = 1 ]; then
        echo "[$(date '+%F %T')] hard reconnect skipped: settings disconnect latch is set"
        return 0
    fi
    # 去重：Hall 抖动可以在一秒内产生多个离座边沿，而本函数会真实断开一次笔。
    # 没有这层保护就会变成重连风暴。
    # 注意这里只**检查**，时间戳要等首次 OEM 投递成功之后才写：延后路径不能
    # 消耗去重窗口，否则「用户下笔即重试」会被自己刚写的 10 秒窗口挡住。
    hard_now=$(date '+%s' 2>/dev/null)
    case "$hard_now" in ''|*[!0-9]*) hard_now=0 ;; esac
    hard_prev=$(cat "$PEN_HARD_RECONNECT_DEDUP" 2>/dev/null)
    case "$hard_prev" in
        ''|*[!0-9]*) ;;
        *)
            if [ "$hard_now" -ge "$hard_prev" ] && [ "$((hard_now - hard_prev))" -lt "$PEN_HARD_RECONNECT_DEDUP_SECONDS" ]; then
                echo "[$(date '+%F %T')] hard reconnect skipped: previous one ran $((hard_now - hard_prev))s ago"
                return 0
            fi
            ;;
    esac
    # 第一步的原厂 DISCONNECT 同时充当「OEM 通路是否可达」的探针。
    # 必须**先确认可达再动手**：否则会先断链、再发现连不上，把笔留在一个比
    # 僵尸连接更糟的状态。判据用真实投递结果，不用锁屏状态等代理判据（见
    # PEN_PENDING_RECONNECT 的设计原则）。失败时挂起到用户下一次下笔。
    if ! request_oem_pen_action "$OEM_DISCONNECT_ACTION"; then
        echo "[$(date '+%F %T')] hard pen reconnect deferred: OEM channel unreachable; will retry on next pen-down"
        : >"$PEN_PENDING_RECONNECT"
        spawn_deferred_hard_reconnect
        return 0
    fi
    echo "$hard_now" >"$PEN_HARD_RECONNECT_DEDUP"
    echo "[$(date '+%F %T')] hard pen reconnect: breaking possible zombie ACL first"
    run_hidctl disconnect
    # 等 HOGP 真的落下（僵尸消失）。最长 6 秒；会话本就健康时会立刻退出。
    waited=0
    while [ "$waited" -lt 6 ]; do
        sleep_sec 1
        waited=$((waited + 1))
        bt_stack_hogp_live || break
    done
    # request_pen_disconnect 走的是原厂 DISCONNECT_PENCIL，它会自动武装
    # lenovo_pen_disconnect_requested=1。那是我们自己刚造成的闩锁，必须在重连前
    # 清掉，否则 request_pen_connect 会被它吃掉（11:11:57 实测日志
    # "stock DISCONNECT_PENCIL armed disconnect latch"）。用户主动点「断开连接」
    # 造成的闩锁已在上面提前返回，不会被这里误清。
    #
    # v0.1.15：**必须同时清 lenovo_pen_user_disconnect_requested**。Hook 的
    # IpeManagerHooks 在 CoreService.onStartCommand 里对 DISCONNECT_PENCIL 是
    # **两个闩锁一起置 1** 的（对 CONNECT_PENCIL 则一起清 0），只清前者会让
    # request_pen_connect 立刻以 "pen connect skipped: user disconnect choice is
    # active" 返回 —— 链被我们亲手断掉、又拒绝重建，状态比原来的僵尸连接更糟。
    # 12:33:05 实测就是这样：hard reconnect 发完 DISCONNECT 之后 CONNECT 被跳过，
    # 只因为用户 5 秒后又把笔吸回座上（吸附边沿会清闩锁）才没暴露出来。
    settings put global lenovo_pen_disconnect_requested 0 >/dev/null 2>&1
    settings put global lenovo_pen_user_disconnect_requested 0 >/dev/null 2>&1
    # 绕过 request_pen_connect 的 8 秒去重：本函数的语义就是「强制重连一次」。
    rm -f "$PEN_CONNECT_DEDUP_FILE" 2>/dev/null
    sleep_sec 1
    request_pen_connect
    # 成功发出即清掉挂起标记：等待者的循环条件就是它，清掉等于通知「收工」。
    # 必须在 request_pen_connect 之后清 —— 连接这段同样依赖 OEM 通路，
    # 中途失败会重新落 pending，等待者据此继续等下一次下笔。
    rm -f "$PEN_PENDING_RECONNECT"
    echo "[$(date '+%F %T')] hard pen reconnect issued (zombie break waited ${waited}s)"
}

# The stock settings action updates the IPe state, but on this port HID Host
# remains connected. Enforce an explicit settings-page Disconnect at both the
# vendor CoreService and the actual HID profile. A 1 -> 0 transition is the
# only runtime path that requests a connect; an idle 0 with no live link is
# left alone because the bounded boot loop is the only automatic recovery.
monitor_hid_latch() {
    last=$(settings get global lenovo_pen_disconnect_requested 2>/dev/null | tr -d '\r')
    case "$last" in
        1|0) ;;
        *) last=-1 ;;
    esac
    repeat=0
    while [ ! -e "$CPS_DISABLED" ]; do
        requested=$(settings get global lenovo_pen_disconnect_requested 2>/dev/null | tr -d '\r')
        case "$requested" in
            1)
                if [ "$last" != 1 ]; then
                    request_pen_disconnect
                    repeat=0
                else
                    repeat=0
                fi
                ;;
            0)
                if [ "$last" = 1 ]; then
                    user_requested=$(settings get global lenovo_pen_user_disconnect_requested 2>/dev/null | tr -d '\r')
                    if [ "$user_requested" = 1 ]; then
                        echo "[$(date '+%F %T')] explicit pen connect skipped: user disconnect choice is active"
                    elif real_bt_connected; then
                        echo "[$(date '+%F %T')] explicit pen connect already has a real link"
                    else
                        request_pen_connect_bounded
                    fi
                    repeat=0
                else
                    repeat=0
                fi

                ;;
            *)
                repeat=0
                ;;
        esac
        last="$requested"
        sleep_sec 5
    done
}

# Boot-time monitors start here: after every helper they call (run_hidctl,
# request_oem_pen_action, request_pen_connect, request_pen_disconnect) has
# already been parsed above, so the forked subshells inherit the full symbol
# table and the first magnetic edge cannot hit "request_pen_connect: not
# found". They still start before the boot-connect retry window, preserving
# the original boot-time state publication (connection mirrors + haptics).
monitor_hall_capsule &
monitor_battery_cache &
monitor_charging_cache &
monitor_real_bt_state &

# TB522FU: 充满断电 + 充电通知 + IPeManager 充电状态修正。
# 独立脚本，可用 `touch $MODDIR/disable-charge-guard` 临时停用。
# 用 -f + `sh` 而不是 -x：模块文件权限由打包时的 set_perm 决定，
# 早先漏配导致 charge-guard.sh 为 0644 → -x 判定失败 → 守护静默不启动。
# 另注：pidfile 落在 /data 会跨重启保留，脚本内已用 boot_id + cmdline 双重
# 校验，防止把被内核复用的 PID 误判为"已在运行"（2026-09-18 实测踩坑）。
if [ -f "$MODDIR/charge-guard.sh" ]; then
    echo "[$(date '+%F %T')] launching charge-guard"
    sh "$MODDIR/charge-guard.sh" &
    # 后台确认守护确实起来了；若缺席（单实例误判、异常退出等）补启一次。
    (
        sleep 3
        cg_pid=$(cat "$MODDIR/charge-guard.pid" 2>/dev/null)
        cg_pid=${cg_pid%% *}; case "$cg_pid" in ''|*[!0-9]*) cg_pid= ;; esac
        if [ -z "$cg_pid" ] || [ ! -d "/proc/$cg_pid" ]; then
            echo "[$(date '+%F %T')] charge-guard missing after launch; relaunching"
            sh "$MODDIR/charge-guard.sh" &
        fi
    ) &
fi

# 笔「链路状态守护」（pen-revive-guard.sh v2，2026-09-21 重定位）：
#   完整因果链与五组证伪实验见 docs/pen-sleep-death-analysis.md。
#   笔满电 -> 经带内 ASK 包下令 CPS 驱动 close tx -> 驱动关载波 ->
#   笔失去载波自行关机 -> 蓝牙 HOGP 状态滞后（僵尸连接）-> 吸附边沿的重连
#   被僵尸判据吃掉 -> 用户必须物理重新吸附。
#   【软件无法唤醒已关机的笔】：写 tx_status 只产生 Analog Ping，而 Hall
#   边沿走内核内调用（Digital Ping），笔只认后者。v1 的 TX 脉冲方案已证伪。
# v2 因此不再写 tx_status（一个字节都不写），改为维护
#   settings lenovo_pen_powered_down
# 供本文件 real_bt_connected() 消费，让镜像诚实、重连恢复：
#   touch $MODDIR/pen-revive.dryrun   只记录检测结果（不改 settings）
#   touch $MODDIR/disable-pen-revive  整体停用
# 注意与 charge-guard 的分工：两者都是纯观察者，都不写 tx_status。
if [ -f "$MODDIR/pen-revive-guard.sh" ]; then
    echo "[$(date '+%F %T')] launching pen-revive-guard"
    sh "$MODDIR/pen-revive-guard.sh" &
fi

monitor_hid_latch &

# The ported IPeManager package carries the vendor Bluetooth receivers in
# its resolver table, but their user-0 component state is disabled.  Enable
# only those two stock receivers so the real OAF/ACL events can start
# CoreService under Oppo's own UID; no synthetic event or connection state is
# written here.
for receiver in \
    com.oplus.ipemanager/.btadsorb.ble.BluetoothStatusReceiver \
    com.oplus.ipemanager/.btadsorb.receiver.BluetoothBroadcastReceiver; do
    if pm enable --user 0 "$receiver" >/dev/null 2>&1; then
        echo "[$(date '+%F %T')] enabled Oppo pen receiver=$receiver"
    else
        echo "[$(date '+%F %T')] unable to enable Oppo pen receiver=$receiver"
    fi
done

# On this port the CPS8601 is probed before hall_detect has replayed the
# initial docked state. The vendor hall notifier's real event 1 sequence is
# therefore never emitted at boot: cps_power_gpio (13) is high, but the
# controller's sw_en (10) and boost_mode (108) pins remain low. The second
# Hall node alone is high both when docked and when detached, so gate the
# real GPIO keeper on the validated Hall pair (0:1 == docked). No pen,
# Bluetooth or attention state is synthesized here; the CPS driver must still
# report the actual chip, battery and HID state.
start_cps_gpio() {
    # TB522FU: the CPS8601 driver owns the wireless TX path via the kernel
    # power-supply framework (cps_wls_tx online=1 observed the moment the pen
    # docks). No GPIO keeper is needed here, and the TB710FU line numbers
    # (10/108) are invalid on this board. Keep the hook disabled until a
    # concrete failure is proven on-device.
    return 0
    [ -r "$CPS_PEN_HALL" ] || return 0
    [ "$(read_hall_state)" = 1 ] || return 0
    [ -x "$CPS_HELPER" ] || [ -x "$CPS_GPIOSET" ] || {
        echo "[$(date '+%F %T')] CPS GPIO helper unavailable; wake skipped"
        return 0
    }
    [ -e "$CPS_GPIODEV" ] || return 0

    if [ -r "$CPS_PIDFILE" ]; then
        old_pid=$(cat "$CPS_PIDFILE" 2>/dev/null)
        case "$old_pid" in
            ''|*[!0-9]*) old_pid= ;;
            *) kill -0 "$old_pid" 2>/dev/null && return 0 ;;
        esac
    fi
    rm -f "$CPS_PIDFILE"

    if [ -x "$CPS_HELPER" ]; then
        "$CPS_HELPER" >/dev/null 2>&1 &
        cps_pid=$!
        sleep_sec 1
        if kill -0 "$cps_pid" 2>/dev/null; then
            echo "$cps_pid" >"$CPS_PIDFILE"
            echo "[$(date '+%F %T')] CPS GPIO handle holder started pid=$cps_pid hall=1 gpio=10,108"
            return 0
        fi
        echo "[$(date '+%F %T')] CPS GPIO handle helper exited; using gpioset fallback"
    fi

    (
        cleanup_cps_gpio() {
            "$CPS_GPIOSET" "$CPS_GPIOCHIP" 10=0 108=0 >/dev/null 2>&1
            exit 0
        }
        trap cleanup_cps_gpio HUP INT TERM
        while [ ! -e "$CPS_DISABLED" ] && [ -r "$CPS_PEN_HALL" ] \
                && [ "$(read_hall_state)" = 1 ]; do
            "$CPS_GPIOSET" "$CPS_GPIOCHIP" 10=1 108=1 >/dev/null 2>&1
            # gpioset is a fallback for kernels where the line-holder helper
            # exits. The CPS state is latched; refreshing at 5 s avoids a
            # needless one-Hz process/exec loop while the pen is docked.
            sleep_sec 5
        done
        cleanup_cps_gpio
    ) &
    cps_pid=$!
    echo "$cps_pid" >"$CPS_PIDFILE"
    echo "[$(date '+%F %T')] CPS real wake sequence started pid=$cps_pid hall=1 gpio=10,108"
}

stop_cps_gpio() {
    had_pid=0
    if [ -r "$CPS_PIDFILE" ]; then
        cps_pid=$(cat "$CPS_PIDFILE" 2>/dev/null)
        case "$cps_pid" in
            ''|*[!0-9]*) ;;
            *)
                had_pid=1
                kill "$cps_pid" 2>/dev/null
                ;;
        esac
        rm -f "$CPS_PIDFILE"
    fi
    [ "$had_pid" = 1 ] && "$CPS_GPIOSET" "$CPS_GPIOCHIP" 10=0 108=0 >/dev/null 2>&1
}

monitor_cps_gpio() {
    wait_count=0
    while [ ! -r "$CPS_PEN_HALL" ] && [ "$wait_count" -lt 120 ]; do
        sleep_sec 1
        wait_count=$((wait_count + 1))
    done
    while [ ! -e "$CPS_DISABLED" ]; do
        if [ -r "$CPS_PEN_HALL" ] && [ "$(read_hall_state)" = 1 ]; then
            start_cps_gpio
        else
            stop_cps_gpio
        fi
        sleep_sec 2
    done
    stop_cps_gpio
}

wait_for_cps_power() {
    wait_count=0
    while [ ! -e "$CPS_DISABLED" ] && [ "$wait_count" -lt 20 ]; do
        if [ "$(read_hall_state)" = 0 ]; then
            echo "[$(date '+%F %T')] CPS boot power skipped: pen is not magnetically docked"
            return 1
        fi
        if [ -r "$CPS_PEN_HALL" ] && [ "$(read_hall_state)" = 1 ]; then
            start_cps_gpio
            cps_pid=$(cat "$CPS_PIDFILE" 2>/dev/null)
            case "$cps_pid" in
                ''|*[!0-9]*) ;;
                *)
                    if kill -0 "$cps_pid" 2>/dev/null; then
                        echo "[$(date '+%F %T')] CPS boot power ready pid=$cps_pid"
                        return 0
                    fi
                    ;;
            esac
        fi
        sleep_sec 1
        wait_count=$((wait_count + 1))
    done
    echo "[$(date '+%F %T')] CPS boot power wait ended without a live GPIO holder"
    return 1
}

# TB522FU CPS wireless charging is managed by kernel power supply driver; monitor_cps_gpio is unneeded
# monitor_cps_gpio &

# CPS power is a charging concern only. Bluetooth pen recovery must not wait
# for Hall/CPS because the OEM pen protocol is wireless even while undocked.
if [ "$(read_hall_state)" = 1 ] && wait_for_cps_power; then
    echo "[$(date '+%F %T')] CPS boot power ready before Bluetooth retries"
fi
touch "$PEN_BOOT_READY_FILE"

# Re-emit the driver's current INFO/MAC/TOUCH_INFORMATION snapshot after the
# LSPosed system_server observer has started.
if [ -w "$UEVENT" ]; then
    echo change >"$UEVENT"
    echo "[$(date '+%F %T')] PEN_FRAMEWORK uevent requested"
fi
if [ -w "$CPS_UEVENT" ]; then
    echo change >"$CPS_UEVENT"
    echo "[$(date '+%F %T')] CPS uevent requested"
fi

# Keep the real vendor request alive across Bluetooth's late service startup
# window.  Stop as soon as the ACL/GATT callback has reported a live link; do
# not send the old RECONNECT_PEN broadcast, which clears the settings latch and
# invokes a synthetic system_server replay before the real link exists.
# The Lenovo pen powers itself off when it is not magnetically docked, so
# actively searching for it over Bluetooth is pointless (and the early pokes
# used to restart the adapter). Only connect after the CPS power-on, which can
# only wake a docked pen; the dock-attach edge reconnects it later.
# Do not poke the Bluetooth stack while it is still coming up.
bt_wait=0
while [ "$bt_wait" -lt 60 ]; do
    [ "$(settings get global bluetooth_on 2>/dev/null | tr -d '\r')" = 1 ] && break
    sleep_sec 2
    bt_wait=$((bt_wait + 2))
done
requested=$(settings get global lenovo_pen_disconnect_requested 2>/dev/null | tr -d '\r')
user_requested=$(settings get global lenovo_pen_user_disconnect_requested 2>/dev/null | tr -d '\r')
connected=$(settings get global lenovo_pen_link_connected 2>/dev/null | tr -d '\r')
if [ "$connected" = 1 ]; then
    echo "[$(date '+%F %T')] boot pen connect confirmed by real ACL/GATT state"
elif [ "$requested" = 1 ] || [ "$user_requested" = 1 ]; then
    echo "[$(date '+%F %T')] boot pen connect skipped: Settings disconnect latch is set"
elif [ "$(read_hall_state)" = 1 ]; then
    # Docked: the CPS boot power sequence already ran; connect once and give
    # the link a bounded window to come up.
    request_pen_connect
    echo "[$(date '+%F %T')] real OEM boot connect requested (docked/CPS powered)"
    attempt=2
    while [ "$attempt" -le 4 ] && [ ! -e "$CPS_DISABLED" ]; do
        sleep_sec 12
        connected=$(settings get global lenovo_pen_link_connected 2>/dev/null | tr -d '\r')
        if [ "$connected" = 1 ]; then
            echo "[$(date '+%F %T')] boot pen connect confirmed by real ACL/GATT state"
            break
        fi
        request_pen_connect
        echo "[$(date '+%F %T')] real OEM boot connect retry attempt=$attempt"
        attempt=$((attempt + 1))
    done
else
    echo "[$(date '+%F %T')] pen not docked; boot connect skipped (CPS can only wake a docked pen)"
fi

# Keep all monitor children alive after the boot retry window. Exiting the
# shell here can orphan/kill the CPS, Hall and HID reconciliation loops on
# some KernelSU/Magisk launchers, which leaves only the already-open BLE link.
while [ ! -e "$CPS_DISABLED" ]; do
    sleep_sec 30
done

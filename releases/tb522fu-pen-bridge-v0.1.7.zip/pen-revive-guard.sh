#!/system/bin/sh
# ============================================================================
# TB522FU 手写笔「失联复活」看门狗 (pen revive guard) v1
# ----------------------------------------------------------------------------
# 症状：笔磁吸到 dock 后经常断连，必须物理重新吸附一次才能激活。
#
# 因果链（2026-09-21 定位）：
#   1) 笔吸附 -> Hall 边沿 -> CPS 驱动开 TX（Qi 送电）-> 笔上电 -> BLE 建立
#   2) 笔满电 -> 驱动【自己】关 TX（实测吸附后 15 秒~1 分钟）
#   3) 笔失去 Qi 供电 -> 按固件行为自行关机
#      （service.sh 原文：The Lenovo pen powers itself off when it is not
#        magnetically docked）
#   4) 笔是突然掉电，不走正常 BLE disconnect -> 蓝牙栈 HOGP profile state
#      不清零 -> real_bt_connected() 仍返回真 = 僵尸连接。于是
#      monitor_real_bt_state 以为一切正常，而 request_pen_connect 只在 Hall
#      物理边沿调用 => 断连后没有任何逻辑主动重连。
#   => 死锁：笔关机 -> 无法发带内 charging_cmd 要求补电 -> 驱动等笔请求 ->
#     永远等。只能靠物理重新吸附打破。
#
# 本脚本做的事：软件等价的「重新吸附」——检测到笔物理在场但电子失联时，
# 打一次 TX 脉冲强制送电，让笔重新上电。
#
# 实测依据（2026-09-21）：
#   * 写 `1` 到 tx_status 有效：cps_wls_en 0->1，cps_boost_mode 同步变 1，
#     且驱动不会立刻自己关回（空载实测 5 秒后仍为 1）。-> 软件送电这条路通。
#   * 笔不在时 online=0、capacity=0（online=驱动认为线圈上是否有笔）。
#
# 安全约束（重要）：
#   * 【只写 1，从不写 0】。关 TX 是驱动自己的事。charge-guard v2 的教训正是
#     用户态抢先写 0 打断了驱动正常的充满周期；本脚本方向相反且仅在失联时动作。
#   * 脉冲后【放手】，不再干预，由驱动自己决定何时关。
#   * 有界：一次失联最多 MAX_PULSE 次脉冲，之后退避到下次吸附边沿重置。
#   * 默认【LIVE】：判据成立即打脉冲。想先观测不动作，见下方开关文件。
#
# 开关文件：
#   $MODDIR/pen-revive.dryrun   存在=dry-run（只记录，不写 tx_status）
#                               【不存在=LIVE（默认）】
#   $MODDIR/disable-pen-revive  存在=整个守护停摆
# ============================================================================

MODDIR=${0%/*}
LOG="$MODDIR/pen-revive.log"
PIDFILE="$MODDIR/pen-revive.pid"

HALL3=/sys/devices/virtual/hall/och1909/hall3
PS_ONLINE=/sys/class/power_supply/cps_wls_tx/online
PS_CAPACITY=/sys/class/power_supply/cps_wls_tx/capacity

POLL_SEC=${POLL_SEC:-15}
# TX 关闭后先等这么久再判定失联：充满后正常断电不应被立刻打断。
GRACE_SEC=${GRACE_SEC:-45}
# 兜底判据 P3：不管 online / HOGP 翻不翻转，TX 关闭超过这个时长即判定笔已
# 掉电关机。存在理由 —— 两个活性判据都可能失效（见下），而"TX 停送电 -> 笔
# 掉电"是本故障的确定性因果：
#   * P1 (online=0) 极可能不翻转：docs/cps-charger-driver-analysis.md 第 93 行
#     实测「cps_wls_en:0（已断电）时 online 仍是 1」，说明 online 反映线圈
#     上有无物体，而不是笔有没有在回应带内通信。
#   * P2 (HOGP 断开) 同样可疑：全部历史日志里 real BT state mirror 从未出现
#     过 connected=0，僵尸连接可以长期保持。
# 误脉冲的代价很低（写 1 开送电，驱动有过充截止兜底，且 MAX_PULSE 有界），
# 而漏判的代价是用户必须手动重新吸附 —— 所以宁可偏激进。
# 默认 60s：驱动实测在吸附后 15~60s 就关 TX，笔随即掉电；判得太晚用户早就
# 手动重新吸附过了。
LOST_AFTER_SEC=${LOST_AFTER_SEC:-60}
MAX_PULSE=${MAX_PULSE:-3}
DRYRUN_FLAG="$MODDIR/pen-revive.dryrun"
DISABLE_FLAG="$MODDIR/disable-pen-revive"

TX_NODE=
for d in /sys/bus/i2c/devices/*-0041; do
    [ -r "$d/tx_status" ] && { TX_NODE="$d/tx_status"; break; }
done

PENLOG_MAX_LINES=300
if [ -f "$MODDIR/bin/penlog.sh" ]; then
    . "$MODDIR/bin/penlog.sh"
fi
if type penlog_append >/dev/null 2>&1; then
    log() { penlog_append "$LOG" "$*"; }
else
    log() { echo "[$(date '+%F %T')] $*" >>"$LOG"; }
fi

tx_get() {
    [ -n "$TX_NODE" ] || { echo -1; return; }
    v=$(cat "$TX_NODE" 2>/dev/null)
    case "$v" in
        *cps_wls_en:1*) echo 1 ;;
        *cps_wls_en:0*) echo 0 ;;
        *) echo -1 ;;
    esac
}

hall_docked() {
    h=$(cat "$HALL3" 2>/dev/null)
    h=${h##* }
    [ "$h" = "0" ] && echo 1 || echo 0
}

# 驱动认为线圈上有没有笔（带内通信判据，笔关机应失效）
ps_online() {
    v=$(cat "$PS_ONLINE" 2>/dev/null | tr -d '\r')
    case "$v" in 0|1) echo "$v" ;; *) echo -1 ;; esac
}

ps_capacity() {
    v=$(cat "$PS_CAPACITY" 2>/dev/null | tr -d '\r')
    case "$v" in ''|*[!0-9]*) echo -1 ;; *) echo "$v" ;; esac
}

# 真实 BLE 链路（HOGP state=2）。注意：笔掉电后该状态滞后 —— 这就是僵尸连接
# 的来源，所以它只能作为辅助判据，不能单独信任。
#
# MAC 来源是 service.sh 维护的 ipe_pencil_mac_addr（不是 *_mac_address）。
# 拿不到 MAC 时绝不能返回"未连接"：那会让 P2 恒真，把每次正常充满都误判成
# 失联并打脉冲。宁可漏判，不可误判 —— 此时退化为只用 P1。
real_bt_connected() {
    mac=$(settings get global ipe_pencil_mac_addr 2>/dev/null | tr -d '\r')
    case "$mac" in
        *:*:*:*:*:*:*) ;;
        *) return 0 ;;   # MAC 未知 -> 假定仍在，不产生 P2
    esac
    tail=${mac#*:*:*:*:}
    [ -n "$tail" ] || return 0
    tail=$(printf '%s' "$tail" | tr 'A-Z' 'a-z')
    dumpsys bluetooth_manager 2>/dev/null | tr 'A-Z' 'a-z' \
        | grep -E "$tail .*hogp connection state=2" >/dev/null 2>&1
}

# --- 单实例保护：与 charge-guard 同款（pidfile + boot_id + cmdline 三验）----
cur_boot=$(cat /proc/sys/kernel/random/boot_id 2>/dev/null)
if [ -r "$PIDFILE" ]; then
    read -r old old_boot <"$PIDFILE" 2>/dev/null
    case "$old" in ''|*[!0-9]*) old= ;; esac
    if [ -n "$old" ]; then
        if [ -n "$cur_boot" ] && [ -n "$old_boot" ] && [ "$old_boot" != "$cur_boot" ]; then
            log "pidfile pid=$old from previous boot; starting fresh"
        elif kill -0 "$old" 2>/dev/null; then
            old_cmd=$(tr '\0' ' ' <"/proc/$old/cmdline" 2>/dev/null)
            case "$old_cmd" in
                *pen-revive-guard.sh*)
                    log "already running as pid=$old; not starting a second instance"
                    exit 0 ;;
                *)
                    log "pidfile pid=$old is a recycled process ($old_cmd); starting fresh" ;;
            esac
        else
            log "pidfile pid=$old not alive; starting fresh"
        fi
    fi
fi
echo "$$ ${cur_boot:-}" >"$PIDFILE"

# NOTE: the dry-run flag is NOT auto-created here on purpose. Auto-creating it
# would resurrect dry-run on every restart after the operator cleared it, i.e.
# "rm pen-revive.dryrun" would silently stop meaning anything. It is created
# once at deploy time; absence = live.

log "pen-revive-guard v1 started: tx_node=${TX_NODE:-NONE} poll=${POLL_SEC}s grace=${GRACE_SEC}s max_pulse=$MAX_PULSE"

lost_since=0
tx_off_since=0
pulses=0
prev_docked=-1

while true; do
    if [ -f "$DISABLE_FLAG" ]; then
        sleep "$POLL_SEC"
        continue
    fi

    now=$(date '+%s' 2>/dev/null)
    case "$now" in ''|*[!0-9]*) now=0 ;; esac

    docked=$(hall_docked)
    tx=$(tx_get)
    online=$(ps_online)
    cap=$(ps_capacity)

    if [ "$docked" != 1 ]; then
        # 笔不在：会话结束，为下次吸附重置预算
        if [ "$prev_docked" = 1 ]; then
            log "pen detached; pulse budget reset (used $pulses)"
        fi
        [ "$prev_docked" != 0 ] && log "idle: not docked tx=$tx online=$online cap=$cap"
        prev_docked=0
        lost_since=0
        tx_off_since=0
        pulses=0
        sleep "$POLL_SEC"
        continue
    fi

    if [ "$prev_docked" != 1 ]; then
        log "pen docked: tx=$tx online=$online cap=$cap"
        prev_docked=1
    fi

    # 正在送电 = 正常，清掉失联计时
    if [ "$tx" = 1 ]; then
        if [ "$lost_since" != 0 ]; then
            log "tx back on; link considered healthy (online=$online cap=$cap)"
        fi
        lost_since=0
        tx_off_since=0
        pulses=0
        sleep "$POLL_SEC"
        continue
    fi

    # --- tx=0：驱动停止送电。判断笔是"充满静置"还是"已经关机" ---
    # P1: 驱动说线圈上没有笔（但 Hall 说笔在）-> 笔已不响应带内通信 = 关机
    # P2: HOGP 链路断开（滞后，但一旦翻转就是铁证）
    reason=""
    if [ "$online" = 0 ]; then
        reason="P1(online=0 驱动看不到笔)"
    fi
    if real_bt_connected; then
        bt=1
    else
        bt=0
        if [ -n "$reason" ]; then
            reason="$reason+P2(HOGP断开)"
        else
            reason="P2(HOGP断开)"
        fi
    fi

    # P3 兜底：TX 关闭累计时长达标即判定失联，完全不依赖 online / HOGP。
    [ "$tx_off_since" = 0 ] && tx_off_since=$now
    off_elapsed=$((now - tx_off_since))
    if [ "$off_elapsed" -ge "$LOST_AFTER_SEC" ] && [ "$pulses" -lt "$MAX_PULSE" ]; then
        reason="P3(TX 已关闭 ${off_elapsed}s >= ${LOST_AFTER_SEC}s)"
        log "quiet-timeout: online=$online bt=$bt cap=$cap tx_off=${off_elapsed}s -> treat pen as powered down"
    fi

    if [ -z "$reason" ]; then
        # 笔在线圈上且 BLE 还在 = 正常充满静置，不动
        if [ "$lost_since" != 0 ]; then
            log "pen responsive again; cleared (online=$online bt=$bt cap=$cap)"
        fi
        lost_since=0
        sleep "$POLL_SEC"
        continue
    fi

    [ "$lost_since" = 0 ] && lost_since=$now
    elapsed=$((now - lost_since))

    if [ "$elapsed" -lt "$GRACE_SEC" ]; then
        log "suspect lost: $reason tx=0 online=$online bt=$bt cap=$cap (${elapsed}s/${GRACE_SEC}s, no action yet)"
        sleep "$POLL_SEC"
        continue
    fi

    if [ "$pulses" -ge "$MAX_PULSE" ]; then
        # 有界：别把一次失联变成永久脉冲循环
        log "pulse budget exhausted ($pulses/$MAX_PULSE); waiting for next attach edge - $reason"
        sleep "$POLL_SEC"
        continue
    fi

    if [ -f "$DRYRUN_FLAG" ]; then
        log "[DRYRUN] would pulse tx=1 - $reason elapsed=${elapsed}s online=$online bt=$bt cap=$cap"
    else
        if [ -n "$TX_NODE" ] && printf '1\n' >"$TX_NODE" 2>/dev/null; then
            pulses=$((pulses + 1))
            log "PULSE tx=1 sent (#$pulses/$MAX_PULSE) - $reason elapsed=${elapsed}s"
            sleep 5
            if real_bt_connected; then bt2=1; else bt2=0; fi
            log "post-pulse: tx=$(tx_get) online=$(ps_online) cap=$(ps_capacity) bt=$bt2"
        else
            log "PULSE FAILED: cannot write $TX_NODE"
        fi
        # 打完就放手：不再写任何东西，交给驱动
        lost_since=$now
    fi

    sleep "$POLL_SEC"
done
